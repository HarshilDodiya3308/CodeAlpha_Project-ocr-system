import { pgTable, serial, text, real, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const recognitionsTable = pgTable("recognitions", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  confidence: real("confidence").notNull(),
  mode: text("mode").notNull().default("auto"),
  imageUrl: text("image_url"),
  heatmapUrl: text("heatmap_url"),
  processingTimeMs: integer("processing_time_ms").notNull().default(0),
  topPredictions: jsonb("top_predictions").$type<Array<{ character: string; probability: number }>>().notNull().default([]),
  segments: jsonb("segments").$type<Array<{ text: string; confidence: number; boundingBox: { x: number; y: number; width: number; height: number } }>>().notNull().default([]),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertRecognitionSchema = createInsertSchema(recognitionsTable).omit({ id: true, createdAt: true });
export type InsertRecognition = z.infer<typeof insertRecognitionSchema>;
export type Recognition = typeof recognitionsTable.$inferSelect;
