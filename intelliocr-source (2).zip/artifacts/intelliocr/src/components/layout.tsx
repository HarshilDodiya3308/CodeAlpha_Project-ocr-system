import React from "react";
import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Activity, History, Shapes, BrainCircuit } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Dashboard", icon: Activity },
    { href: "/recognize", label: "Recognize", icon: BrainCircuit },
    { href: "/history", label: "History", icon: History },
    { href: "/analytics", label: "Analytics", icon: Activity },
    { href: "/models", label: "Models", icon: Shapes },
  ];

  return (
    <SidebarProvider>
      <div className="flex min-h-[100dvh] w-full">
        <Sidebar className="border-r border-border bg-sidebar">
          <SidebarHeader className="h-16 flex items-center px-4 border-b border-border">
            <Link href="/" className="flex items-center gap-2 font-bold text-lg tracking-tight text-primary">
              <BrainCircuit className="w-6 h-6" />
              <span>IntelliOCR</span>
            </Link>
          </SidebarHeader>
          <SidebarContent className="p-4">
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.href || (item.href !== "/" && location.startsWith(item.href))}
                    className="font-medium h-10"
                  >
                    <Link href={item.href} className="flex items-center gap-3">
                      <item.icon className="w-4 h-4" />
                      {item.label}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarContent>
          <SidebarFooter className="p-4 border-t border-border">
            <div className="text-xs text-muted-foreground font-mono">
              IntelliOCR Platform v1.0.0
            </div>
          </SidebarFooter>
        </Sidebar>
        
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-16 flex items-center px-4 border-b border-border bg-background lg:hidden">
            <SidebarTrigger />
            <div className="ml-4 font-bold text-primary flex items-center gap-2">
              <BrainCircuit className="w-5 h-5" />
              <span>IntelliOCR</span>
            </div>
          </header>
          <main className="flex-1 overflow-auto bg-background p-6">
            <div className="max-w-7xl mx-auto w-full">
              {children}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
