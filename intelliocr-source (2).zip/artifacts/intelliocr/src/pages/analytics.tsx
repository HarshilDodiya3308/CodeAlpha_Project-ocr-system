import {
  useGetAnalyticsSummary,
  useGetCharacterFrequency,
  useGetAccuracyTimeline,
  useGetModeBreakdown,
  getGetAnalyticsSummaryQueryKey,
  getGetCharacterFrequencyQueryKey,
  getGetAccuracyTimelineQueryKey,
  getGetModeBreakdownQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend,
} from "recharts";
import { TrendingUp, BrainCircuit, Scan, Clock, CheckCircle2, Activity, BarChart3 } from "lucide-react";

const CHART_COLORS = [
  "hsl(199 100% 45%)",
  "hsl(250 80% 62%)",
  "hsl(158 82% 42%)",
  "hsl(32 95% 55%)",
  "hsl(290 75% 57%)",
];

function SummaryCard({
  title,
  value,
  icon: Icon,
  sub,
  color = "text-primary bg-primary/10",
}: {
  title: string;
  value: string | number;
  icon: React.ComponentType<{ className?: string }>;
  sub?: string;
  color?: string;
}) {
  return (
    <Card className="stat-card-3d">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide whitespace-nowrap font-semibold mb-1.5">{title}</p>
            <p className="text-3xl font-bold font-mono leading-none">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">{sub}</p>}
          </div>
          <div className={`p-2.5 rounded-xl shrink-0 ${color}`}>
            <Icon className="w-5 h-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Analytics() {
  const { data: summary, isLoading: sl } = useGetAnalyticsSummary({ query: { queryKey: getGetAnalyticsSummaryQueryKey() } });
  const { data: charFreq, isLoading: cfl } = useGetCharacterFrequency({ query: { queryKey: getGetCharacterFrequencyQueryKey() } });
  const { data: timeline, isLoading: tl } = useGetAccuracyTimeline({ query: { queryKey: getGetAccuracyTimelineQueryKey() } });
  const { data: modeBreakdown, isLoading: ml } = useGetModeBreakdown({ query: { queryKey: getGetModeBreakdownQueryKey() } });

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <BarChart3 className="w-7 h-7 text-primary" />
          Analytics
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Recognition performance metrics and character statistics</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-4">
        {sl ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="stat-card-3d"><CardContent className="p-5"><Skeleton className="h-20 w-full" /></CardContent></Card>
          ))
        ) : summary ? (
          <>
            <SummaryCard title="Total" value={summary.totalRecognitions.toLocaleString()} icon={BrainCircuit} color="text-primary bg-primary/10" />
            <SummaryCard title="Confidence" value={`${Math.round(summary.averageConfidence * 100)}%`} icon={CheckCircle2} sub="average" color="text-emerald-500 bg-emerald-100 dark:bg-emerald-900/20" />
            <SummaryCard title="Today" value={summary.recognitionsToday} icon={Activity} color="text-purple-500 bg-purple-100 dark:bg-purple-900/20" />
            <SummaryCard title="Success" value={`${Math.round(summary.successRate * 100)}%`} icon={TrendingUp} sub="> 50% confidence" color="text-amber-500 bg-amber-100 dark:bg-amber-900/20" />
            <SummaryCard title="Avg Speed" value={`${Math.round(summary.averageProcessingTimeMs)}ms`} icon={Clock} color="text-sky-500 bg-sky-100 dark:bg-sky-900/20" />
            <SummaryCard title="Top Char" value={summary.topCharacter || "—"} icon={Scan} sub="most recognized" color="text-rose-500 bg-rose-100 dark:bg-rose-900/20" />
          </>
        ) : null}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <Card className="chart-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              Character Frequency
            </CardTitle>
          </CardHeader>
          <CardContent>
            {cfl ? (
              <Skeleton className="h-56 w-full" />
            ) : !charFreq?.length ? (
              <div className="h-56 flex items-center justify-center">
                <p className="text-sm text-muted-foreground">No data yet — run some recognitions first</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={charFreq.slice(0, 12)} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                  <defs>
                    <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(199 100% 52%)" />
                      <stop offset="100%" stopColor="hsl(199 100% 38%)" />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="character" tickFormatter={(v: string) => v.length > 4 ? v.slice(0, 4) + "…" : v} tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))", fontFamily: "monospace", fontWeight: 700 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "10px", fontSize: "12px", boxShadow: "var(--shadow-md)" }}
                    cursor={{ fill: "hsl(var(--muted) / 0.5)", radius: 4 }}
                  />
                  <Bar dataKey="count" fill="url(#barGrad)" radius={[5, 5, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="chart-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" />
              Recognition by Mode
            </CardTitle>
          </CardHeader>
          <CardContent>
            {ml ? (
              <Skeleton className="h-56 w-full" />
            ) : !modeBreakdown?.length ? (
              <div className="h-56 flex items-center justify-center">
                <p className="text-sm text-muted-foreground">No data yet</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <defs>
                    {CHART_COLORS.map((color, i) => (
                      <radialGradient key={i} id={`pie${i}`} cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor={color} stopOpacity={0.9} />
                        <stop offset="100%" stopColor={color} stopOpacity={0.7} />
                      </radialGradient>
                    ))}
                  </defs>
                  <Pie
                    data={modeBreakdown}
                    dataKey="count"
                    nameKey="mode"
                    cx="50%"
                    cy="46%"
                    outerRadius={82}
                    innerRadius={44}
                    paddingAngle={3}
                    label={false}
                    labelLine={false}
                  >
                    {modeBreakdown.map((_, i) => (
                      <Cell key={i} fill={`url(#pie${i % CHART_COLORS.length})`} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "10px", fontSize: "12px", boxShadow: "var(--shadow-md)" }}
                  />
                  <Legend wrapperStyle={{ fontSize: "12px", color: "hsl(var(--muted-foreground))" }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="chart-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            Accuracy Timeline (30 days)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {tl ? (
            <Skeleton className="h-64 w-full" />
          ) : !timeline?.length ? (
            <div className="h-64 flex items-center justify-center">
              <p className="text-sm text-muted-foreground">No timeline data yet — run a few recognitions to see trends</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={timeline} margin={{ top: 4, right: 12, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(199 100% 52%)" stopOpacity={0.2} />
                    <stop offset="100%" stopColor="hsl(199 100% 52%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickFormatter={(v) => new Date(v).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tickFormatter={(v) => `${Math.round(v * 100)}%`}
                  domain={[0, 1]}
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "10px", fontSize: "12px", boxShadow: "var(--shadow-md)" }}
                  formatter={(v: number) => [`${Math.round(v * 100)}%`, "Avg Confidence"]}
                  labelFormatter={(l) => new Date(l).toLocaleDateString()}
                />
                <Line
                  type="monotone"
                  dataKey="averageConfidence"
                  stroke="hsl(199 100% 45%)"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: "hsl(199 100% 45%)", strokeWidth: 0 }}
                  activeDot={{ r: 6, strokeWidth: 0 }}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
