import { useState } from "react";
import { useListHistory, useDeleteHistoryItem, getListHistoryQueryKey, getGetAnalyticsSummaryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { BrainCircuit, Trash2, Clock, ChevronLeft, ChevronRight, Filter, History as HistoryIcon } from "lucide-react";
import { Link } from "wouter";

const MODES = ["all", "digit", "letter", "word", "sentence", "auto"] as const;
const PAGE_SIZE = 20;

const modeColor: Record<string, string> = {
  digit: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  letter: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
  word: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400",
  sentence: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
  auto: "bg-gray-100 text-gray-600 dark:bg-gray-800/40 dark:text-gray-400",
};

export default function History() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [page, setPage] = useState(0);
  const [filterMode, setFilterMode] = useState<string>("all");

  const params = {
    limit: PAGE_SIZE,
    offset: page * PAGE_SIZE,
    ...(filterMode !== "all" ? { mode: filterMode } : {}),
  };

  const { data, isLoading } = useListHistory(params, {
    query: { queryKey: getListHistoryQueryKey(params) }
  });

  const deleteM = useDeleteHistoryItem({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListHistoryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAnalyticsSummaryQueryKey() });
        toast({ title: "Deleted" });
      },
      onError: () => toast({ title: "Failed to delete", variant: "destructive" }),
    },
  });

  const totalPages = data ? Math.ceil(data.total / PAGE_SIZE) : 0;

  const handleFilterChange = (val: string) => {
    setFilterMode(val);
    setPage(0);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <HistoryIcon className="w-7 h-7 text-primary" />
            History
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {data ? `${data.total.toLocaleString()} total recognitions` : "Loading…"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <Select value={filterMode} onValueChange={handleFilterChange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MODES.map((m) => (
                <SelectItem key={m} value={m}>
                  {m === "all" ? "All Modes" : m.charAt(0).toUpperCase() + m.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-5 space-y-3">
              {Array.from({ length: 8 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full rounded-xl" />
              ))}
            </div>
          ) : !data?.items?.length ? (
            <div className="py-20 text-center">
              <div className="empty-state-icon mx-auto mb-4">
                <BrainCircuit className="w-8 h-8 text-primary/50" />
              </div>
              <p className="text-muted-foreground text-sm">No recognitions found.</p>
              <Button className="mt-4 btn-glow" asChild size="sm">
                <Link href="/recognize">Start recognizing</Link>
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {data.items.map((item) => (
                <div
                  key={item.id}
                  className="history-row flex items-center justify-between px-5 py-4 group"
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-primary/8 border border-primary/12 flex items-center justify-center shrink-0">
                      <BrainCircuit className="w-5 h-5 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-mono text-sm font-bold truncate max-w-xs text-foreground">
                        {item.text || "(empty)"}
                      </p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <Clock className="w-3 h-3 text-muted-foreground" />
                        <p className="text-xs text-muted-foreground">{new Date(item.createdAt).toLocaleString()}</p>
                        <span className="text-muted-foreground/40">·</span>
                        <p className="text-xs text-muted-foreground font-mono">{item.processingTimeMs}ms</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 ml-4">
                    <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${modeColor[item.mode] ?? modeColor.auto}`}>
                      {item.mode}
                    </span>
                    <span className={`text-sm font-bold font-mono w-10 text-right ${
                      item.confidence >= 0.8
                        ? "text-emerald-500"
                        : item.confidence >= 0.5
                        ? "text-amber-500"
                        : "text-red-500"
                    }`}>
                      {Math.round(item.confidence * 100)}%
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="opacity-0 group-hover:opacity-100 transition-opacity w-8 h-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={() => deleteM.mutate({ id: item.id })}
                      disabled={deleteM.isPending}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page <span className="font-semibold">{page + 1}</span> of <span className="font-semibold">{totalPages}</span>
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
