import { useGetModels, getGetModelsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { BrainCircuit, CheckCircle2, Layers, Tag, Zap } from "lucide-react";
import { Link } from "wouter";

const modeColors: Record<string, string> = {
  digit: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  letter: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
  word: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400",
  sentence: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
  auto: "bg-gray-100 text-gray-600 dark:bg-gray-800/40 dark:text-gray-400",
};

const modelGradients = [
  "from-cyan-500 to-blue-500",
  "from-violet-500 to-purple-500",
  "from-emerald-500 to-teal-500",
  "from-orange-500 to-amber-500",
];

export default function Models() {
  const { data: models, isLoading } = useGetModels({
    query: { queryKey: getGetModelsQueryKey() }
  });

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Model Library</h1>
          <p className="text-muted-foreground text-sm mt-1">Available OCR engines and their accuracy profiles</p>
        </div>
        <Button asChild size="sm" variant="outline">
          <Link href="/recognize">
            <Zap className="w-4 h-4 mr-2 text-primary" />
            Try Recognition
          </Link>
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="card-3d">
              <CardContent className="p-6">
                <Skeleton className="h-44 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : !models?.length ? (
        <div className="py-20 text-center">
          <div className="empty-state-icon mx-auto mb-4">
            <BrainCircuit className="w-8 h-8 text-primary/50" />
          </div>
          <p className="text-muted-foreground text-sm">No models available.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {models.map((model, idx) => (
            <Card key={model.id} className="model-card overflow-hidden">
              <div className={`h-1 w-full bg-gradient-to-r ${modelGradients[idx % modelGradients.length]}`} />
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 bg-gradient-to-br ${modelGradients[idx % modelGradients.length]} shadow-sm`}>
                      <BrainCircuit className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-bold">{model.name}</CardTitle>
                      <div className="flex items-center gap-1 mt-0.5">
                        <Tag className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground font-mono">v{model.version}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-2xl font-bold font-mono text-primary leading-none">
                      {Math.round(model.accuracy * 100)}%
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">accuracy</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4 pt-0">
                <p className="text-sm text-muted-foreground leading-relaxed">{model.description}</p>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Accuracy Score</span>
                    <span className="text-xs font-mono font-bold text-foreground">{Math.round(model.accuracy * 100)}%</span>
                  </div>
                  <div className="h-2 rounded-full overflow-hidden bg-muted">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${modelGradients[idx % modelGradients.length]}`}
                      style={{ width: `${model.accuracy * 100}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-1.5 mb-2">
                    <Layers className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Supported Modes</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {model.supportedModes.map((m) => (
                      <span key={m} className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${modeColors[m] ?? modeColors.auto}`}>
                        {m}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">Active &amp; Ready</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="glass-card rounded-xl p-5">
        <p className="text-sm font-semibold mb-1.5 flex items-center gap-2">
          <BrainCircuit className="w-4 h-4 text-primary" />
          About IntelliOCR Models
        </p>
        <p className="text-xs text-muted-foreground leading-relaxed">
          All models are based on Tesseract v5 LSTM architecture running entirely in your browser — no data leaves your device.
          Mode-specific models use character whitelists for maximum precision on constrained tasks.
          The CRNN+CTC engine excels at continuous cursive handwriting across multiple words and sentences.
        </p>
      </div>
    </div>
  );
}
