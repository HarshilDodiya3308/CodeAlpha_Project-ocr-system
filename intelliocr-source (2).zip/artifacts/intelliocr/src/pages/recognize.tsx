import { useState, useRef, useCallback, useEffect } from "react";
import { createWorker } from "tesseract.js";
import { useRecognizeImage, getListHistoryQueryKey, getGetAnalyticsSummaryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import {
  Upload, Pencil, RotateCcw, Scan, CheckCircle2, Clock, Layers,
  BrainCircuit, Sparkles, BarChart3
} from "lucide-react";

type OcrMode = "auto" | "digit" | "letter" | "word" | "sentence";

interface RecognitionResult {
  id: number;
  text: string;
  confidence: number;
  mode: string;
  topPredictions: Array<{ character: string; probability: number }>;
  processingTimeMs: number;
  segments: Array<{ text: string; confidence: number; boundingBox: { x: number; y: number; width: number; height: number } }>;
  createdAt: string;
}

type OcrStatus = "idle" | "loading" | "recognizing" | "saving" | "done" | "error";

const STATUS_LABELS: Record<OcrStatus, string> = {
  idle: "Ready",
  loading: "Initializing engine…",
  recognizing: "Analyzing handwriting…",
  saving: "Saving result…",
  done: "Complete",
  error: "Error",
};

const CHAR_WHITELIST: Record<OcrMode, string | null> = {
  digit: "0123456789",
  letter: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
  word: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'-",
  sentence: null,
  auto: null,
};

export default function Recognize() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [mode, setMode] = useState<OcrMode>("auto");
  const [result, setResult] = useState<RecognitionResult | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const [canvasHasContent, setCanvasHasContent] = useState(false);
  const [ocrStatus, setOcrStatus] = useState<OcrStatus>("idle");
  const [ocrProgress, setOcrProgress] = useState(0);
  const [activeTab, setActiveTab] = useState("upload");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const lastPos = useRef<{ x: number; y: number } | null>(null);

  const mutation = useRecognizeImage({
    mutation: {
      onSuccess: (data: RecognitionResult) => {
        setResult(data);
        setOcrStatus("done");
        setOcrProgress(100);
        queryClient.invalidateQueries({ queryKey: getListHistoryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAnalyticsSummaryQueryKey() });
      },
      onError: () => {
        setOcrStatus("error");
        toast({ title: "Save failed", description: "Could not save recognition result.", variant: "destructive" });
      },
    },
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#111827";
    ctx.lineWidth = 5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
  }, []);

  const getPos = (e: React.MouseEvent | React.TouchEvent, canvas: HTMLCanvasElement) => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    if ("touches" in e) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      };
    }
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const startDraw = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setIsDrawing(true);
    const pos = getPos(e, canvas);
    lastPos.current = pos;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }, []);

  const draw = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx || !lastPos.current) return;
    e.preventDefault();
    const pos = getPos(e, canvas);
    ctx.beginPath();
    ctx.moveTo(lastPos.current.x, lastPos.current.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    lastPos.current = pos;
    setCanvasHasContent(true);
  }, [isDrawing]);

  const stopDraw = useCallback(() => {
    setIsDrawing(false);
    lastPos.current = null;
  }, []);

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#111827";
    ctx.lineWidth = 5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    setCanvasHasContent(false);
    setResult(null);
    setOcrStatus("idle");
    setOcrProgress(0);
  };

  const resizeImage = (dataUrl: string, maxPx = 1600): Promise<string> =>
    new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxPx / Math.max(img.width, img.height));
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d")!;
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.92));
      };
      img.src = dataUrl;
    });

  const handleFileChange = (file: File) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      const raw = e.target?.result as string;
      const resized = await resizeImage(raw);
      setPreviewUrl(resized);
      setResult(null);
      setOcrStatus("idle");
      setOcrProgress(0);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) handleFileChange(file);
  };

  const runOcr = async (imageData: string) => {
    setOcrStatus("loading");
    setOcrProgress(10);
    setResult(null);

    try {
      const startTime = Date.now();
      const worker = await createWorker("eng", 1, {
        logger: (m: { status: string; progress: number }) => {
          if (m.status === "recognizing text") {
            setOcrStatus("recognizing");
            setOcrProgress(20 + Math.round(m.progress * 60));
          }
        },
      });

      const whitelist = CHAR_WHITELIST[mode];
      if (whitelist) {
        await worker.setParameters({ tessedit_char_whitelist: whitelist });
      }

      setOcrProgress(25);
      const { data } = await worker.recognize(imageData);
      await worker.terminate();

      const processingTimeMs = Date.now() - startTime;
      const rawText = data.text.trim();
      const confidence = (data.confidence ?? 0) / 100;

      const topPredictions: Array<{ character: string; probability: number }> = [];
      const seenChars = new Set<string>();
      if (data.words && data.words.length > 0) {
        for (const word of data.words) {
          for (const sym of word.symbols ?? []) {
            const ch = sym.text?.trim();
            if (ch && !seenChars.has(ch)) {
              seenChars.add(ch);
              const conf = (sym.confidence ?? 0) / 100;
              topPredictions.push({ character: ch, probability: conf });
            }
          }
          if (topPredictions.length >= 6) break;
        }
      }

      if (topPredictions.length === 0 && rawText) {
        const chars = Array.from(new Set(rawText.replace(/\s/g, "")));
        for (const c of chars.slice(0, 5)) {
          topPredictions.push({ character: c, probability: confidence });
        }
      }

      topPredictions.sort((a, b) => b.probability - a.probability);

      const segments = (data.words ?? []).slice(0, 8).map((w) => ({
        text: w.text?.trim() ?? "",
        confidence: (w.confidence ?? 0) / 100,
        boundingBox: {
          x: w.bbox?.x0 ?? 0,
          y: w.bbox?.y0 ?? 0,
          width: (w.bbox?.x1 ?? 0) - (w.bbox?.x0 ?? 0),
          height: (w.bbox?.y1 ?? 0) - (w.bbox?.y0 ?? 0),
        },
      })).filter((s) => s.text.length > 0);

      setOcrProgress(85);
      setOcrStatus("saving");

      mutation.mutate({
        data: {
          imageData,
          mode,
          text: rawText || "(no text detected)",
          confidence,
          processingTimeMs,
          topPredictions,
          segments,
        },
      });
    } catch (err) {
      console.error("OCR error:", err);
      setOcrStatus("error");
      setOcrProgress(0);
      toast({ title: "OCR failed", description: "Could not process the image. Please try again.", variant: "destructive" });
    }
  };

  const isProcessing = ocrStatus === "loading" || ocrStatus === "recognizing" || ocrStatus === "saving";
  const confidencePct = result ? Math.round(result.confidence * 100) : 0;
  const confidenceColor =
    confidencePct >= 80
      ? "text-emerald-500"
      : confidencePct >= 50
      ? "text-amber-500"
      : "text-red-500";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <BrainCircuit className="w-6 h-6 text-primary" />
          Recognize
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Upload a handwritten image or draw directly — OCR runs instantly in your browser</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3 space-y-4">
          <div className="glass-card rounded-xl p-4 flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Layers className="w-4 h-4" />
              Mode
            </div>
            <Select value={mode} onValueChange={(v) => setMode(v as OcrMode)}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">🔍 Auto Detect</SelectItem>
                <SelectItem value="digit">🔢 Digits (0–9)</SelectItem>
                <SelectItem value="letter">🔤 Letters (A–Z)</SelectItem>
                <SelectItem value="word">💬 Word</SelectItem>
                <SelectItem value="sentence">📝 Sentence</SelectItem>
              </SelectContent>
            </Select>
            {mode !== "auto" && (
              <Badge variant="outline" className="text-xs text-primary border-primary/30 bg-primary/5">
                Optimized whitelist active
              </Badge>
            )}
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full">
              <TabsTrigger value="upload" className="flex-1">
                <Upload className="w-4 h-4 mr-2" />
                Upload Image
              </TabsTrigger>
              <TabsTrigger value="canvas" className="flex-1">
                <Pencil className="w-4 h-4 mr-2" />
                Draw
              </TabsTrigger>
            </TabsList>

            <TabsContent value="upload" className="mt-4">
              <Card className="card-3d">
                <CardContent className="p-4 space-y-4">
                  <div
                    className={`drop-zone rounded-xl p-8 text-center cursor-pointer transition-all ${
                      isDragging
                        ? "drop-zone-active"
                        : ""
                    }`}
                    onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <div className="upload-icon-ring mx-auto mb-4">
                      <Upload className="w-7 h-7 text-primary" />
                    </div>
                    <p className="text-sm font-semibold">Drop image here or click to browse</p>
                    <p className="text-xs text-muted-foreground mt-1">JPG, PNG, JPEG — max 10MB</p>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/jpg,image/jpeg,image/png"
                      className="hidden"
                      onChange={(e) => e.target.files?.[0] && handleFileChange(e.target.files[0])}
                    />
                  </div>

                  {previewUrl && (
                    <div className="space-y-3">
                      <div className="rounded-xl border border-border overflow-hidden bg-muted/30 shadow-inner">
                        <img src={previewUrl} alt="Preview" className="max-h-56 w-full object-contain p-2" />
                      </div>
                      <Button
                        className="w-full btn-glow"
                        onClick={() => runOcr(previewUrl)}
                        disabled={isProcessing}
                        size="lg"
                      >
                        {isProcessing ? (
                          <>
                            <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                            {STATUS_LABELS[ocrStatus]}
                          </>
                        ) : (
                          <>
                            <Scan className="w-4 h-4 mr-2" />
                            Run Recognition
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="canvas" className="mt-4">
              <Card className="card-3d">
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-muted-foreground font-medium">Draw a character or word below</p>
                    <Button variant="outline" size="sm" onClick={clearCanvas}>
                      <RotateCcw className="w-4 h-4 mr-1.5" />
                      Clear
                    </Button>
                  </div>
                  <div className="canvas-container rounded-xl overflow-hidden cursor-crosshair touch-none">
                    <canvas
                      ref={canvasRef}
                      width={600}
                      height={280}
                      className="w-full bg-white"
                      onMouseDown={startDraw}
                      onMouseMove={draw}
                      onMouseUp={stopDraw}
                      onMouseLeave={stopDraw}
                      onTouchStart={startDraw}
                      onTouchMove={draw}
                      onTouchEnd={stopDraw}
                    />
                  </div>
                  {!canvasHasContent && (
                    <p className="text-center text-xs text-muted-foreground">✏️ Start drawing to enable recognition</p>
                  )}
                  <Button
                    className="w-full btn-glow"
                    onClick={() => {
                      const canvas = canvasRef.current;
                      if (!canvas) return;
                      runOcr(canvas.toDataURL("image/png"));
                    }}
                    disabled={isProcessing || !canvasHasContent}
                    size="lg"
                  >
                    {isProcessing ? (
                      <>
                        <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                        {STATUS_LABELS[ocrStatus]}
                      </>
                    ) : (
                      <>
                        <Scan className="w-4 h-4 mr-2" />
                        Recognize Drawing
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {isProcessing && (
            <div className="glass-card rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-primary flex items-center gap-2">
                  <Sparkles className="w-4 h-4 animate-pulse" />
                  {STATUS_LABELS[ocrStatus]}
                </span>
                <span className="font-mono text-xs text-muted-foreground">{ocrProgress}%</span>
              </div>
              <div className="progress-bar-container">
                <div className="progress-bar-fill" style={{ width: `${ocrProgress}%` }} />
              </div>
            </div>
          )}
        </div>

        <div className="lg:col-span-2 space-y-4">
          <Card className={`card-3d transition-all duration-500 ${result ? "result-card-active" : ""}`}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                {result ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                ) : (
                  <Scan className="w-4 h-4 text-muted-foreground" />
                )}
                Recognition Result
                {result && (
                  <Badge variant="outline" className="ml-auto text-xs border-emerald-500/30 text-emerald-600 bg-emerald-500/5">
                    Saved
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {isProcessing ? (
                <div className="space-y-3">
                  <div className="h-20 glass-card rounded-xl animate-pulse" />
                  <div className="h-4 bg-muted rounded-lg w-3/4 animate-pulse" />
                  <div className="h-4 bg-muted rounded-lg w-1/2 animate-pulse" />
                </div>
              ) : result ? (
                <div className="space-y-5 result-reveal">
                  <div className="result-text-box rounded-xl p-5 text-center">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-widest mb-2">Recognized Text</p>
                    <p className="text-5xl font-mono font-bold tracking-widest text-foreground break-all leading-tight">
                      {result.text || "(empty)"}
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    {[
                      {
                        label: "Confidence",
                        value: `${confidencePct}%`,
                        color: confidenceColor,
                        icon: <CheckCircle2 className="w-3.5 h-3.5" />,
                      },
                      {
                        label: "Speed",
                        value: `${result.processingTimeMs}ms`,
                        color: "text-primary",
                        icon: <Clock className="w-3.5 h-3.5" />,
                      },
                      {
                        label: "Mode",
                        value: result.mode,
                        color: "text-foreground",
                        icon: <Layers className="w-3.5 h-3.5" />,
                      },
                    ].map(({ label, value, color, icon }) => (
                      <div key={label} className="stat-mini-card rounded-xl p-3 text-center">
                        <div className={`flex items-center justify-center gap-1 mb-1 ${color} opacity-60`}>
                          {icon}
                          <span className="text-xs">{label}</span>
                        </div>
                        <p className={`text-lg font-bold font-mono ${color}`}>{value}</p>
                      </div>
                    ))}
                  </div>

                  {result.topPredictions?.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-1.5">
                        <BarChart3 className="w-3.5 h-3.5" />
                        Top Predictions
                      </p>
                      <div className="space-y-2">
                        {result.topPredictions.slice(0, 5).map((p, i) => (
                          <div key={i} className="flex items-center gap-3">
                            <span
                              className={`font-mono text-sm font-bold w-7 text-center shrink-0 ${i === 0 ? "text-primary" : "text-foreground"}`}
                            >
                              {p.character}
                            </span>
                            <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all duration-700 ${i === 0 ? "prediction-bar-primary" : "prediction-bar"}`}
                                style={{ width: `${Math.round(p.probability * 100)}%` }}
                              />
                            </div>
                            <span className="text-xs font-mono text-muted-foreground w-10 text-right shrink-0">
                              {Math.round(p.probability * 100)}%
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {result.segments?.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2 flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5" />
                        Word Segments
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {result.segments.slice(0, 6).map((seg, i) => (
                          <div key={i} className="segment-chip">
                            <span className="font-mono text-sm font-semibold">{seg.text}</span>
                            <span className="text-xs text-muted-foreground ml-1.5">{Math.round(seg.confidence * 100)}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="py-12 text-center space-y-3">
                  <div className="empty-state-icon mx-auto">
                    <Scan className="w-8 h-8 text-primary/50" />
                  </div>
                  <p className="text-sm text-muted-foreground">Upload an image or draw to see instant results</p>
                  <p className="text-xs text-muted-foreground/60">OCR runs entirely in your browser</p>
                </div>
              )}
            </CardContent>
          </Card>

          {result && (
            <div className="glass-card rounded-xl p-3 flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4 text-muted-foreground shrink-0" />
              <span className="text-muted-foreground">Saved</span>
              <span className="font-medium ml-auto font-mono text-xs">{new Date(result.createdAt).toLocaleString()}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
