import { useGetAnalyticsSummary, useListHistory, getGetAnalyticsSummaryQueryKey, getListHistoryQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { BrainCircuit, Scan, Clock, CheckCircle2, TrendingUp, ArrowRight, Zap, BarChart3, Shapes } from "lucide-react";

const modeColor: Record<string, string> = {
  digit: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  letter: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
  word: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400",
  sentence: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
  auto: "bg-gray-100 text-gray-600 dark:bg-gray-800/40 dark:text-gray-400",
};

function StatCard({
  title,
  value,
  sub,
  icon: Icon,
  accent = false,
  gradient,
}: {
  title: string;
  value: string | number;
  sub?: string;
  icon: React.ComponentType<{ className?: string }>;
  accent?: boolean;
  gradient?: string;
}) {
  return (
    <Card className="stat-card-3d overflow-hidden">
      <CardContent className="p-0">
        {accent && gradient && (
          <div className={`h-1 w-full ${gradient}`} />
        )}
        <div className="p-5 flex items-start justify-between">
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap mb-1.5">{title}</p>
            <p className="text-3xl font-bold text-foreground font-mono leading-none truncate max-w-[7rem]">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1.5">{sub}</p>}
          </div>
          <div className={`p-2.5 rounded-xl ${accent ? "bg-primary/10" : "bg-muted/70"}`}>
            <Icon className={`w-5 h-5 ${accent ? "text-primary" : "text-muted-foreground"}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const { data: summary, isLoading: summaryLoading } = useGetAnalyticsSummary({
    query: { queryKey: getGetAnalyticsSummaryQueryKey() }
  });
  const { data: historyData, isLoading: historyLoading } = useListHistory(
    { limit: 6, offset: 0 },
    { query: { queryKey: getListHistoryQueryKey({ limit: 6, offset: 0 }) } }
  );

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-1">IntelliOCR AI — Handwritten Character Recognition Platform</p>
        </div>
        <Button asChild size="lg" className="btn-glow shadow-md">
          <Link href="/recognize">
            <Zap className="w-4 h-4 mr-2" />
            New Recognition
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {summaryLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="stat-card-3d">
              <CardContent className="p-5">
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))
        ) : summary ? (
          <>
            <StatCard title="Total" value={summary.totalRecognitions.toLocaleString()} icon={BrainCircuit} accent gradient="bg-gradient-to-r from-primary to-sky-400" />
            <StatCard title="Confidence" value={`${Math.round(summary.averageConfidence * 100)}%`} sub="average" icon={CheckCircle2} />
            <StatCard title="Today" value={summary.recognitionsToday} sub="recognitions" icon={TrendingUp} />
            <StatCard title="Avg Speed" value={`${Math.round(summary.averageProcessingTimeMs)}ms`} sub="processing" icon={Clock} />
            <StatCard title="Success" value={`${Math.round(summary.successRate * 100)}%`} sub="> 50% confidence" icon={Scan} />
            <StatCard title="Top Char" value={summary.topCharacter || "—"} sub="most seen" icon={BrainCircuit} />
          </>
        ) : null}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Clock className="w-4 h-4 text-primary" />
            Recent Activity
          </CardTitle>
          <Button variant="ghost" size="sm" asChild className="text-xs text-muted-foreground hover:text-primary">
            <Link href="/history">
              View all <ArrowRight className="w-3 h-3 ml-1" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          {historyLoading ? (
            <div className="p-5 space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : !historyData?.items?.length ? (
            <div className="p-12 text-center">
              <div className="empty-state-icon mx-auto mb-4">
                <BrainCircuit className="w-8 h-8 text-primary/50" />
              </div>
              <p className="text-sm text-muted-foreground">No recognitions yet.</p>
              <Button className="mt-4 btn-glow" asChild size="sm">
                <Link href="/recognize">Start recognizing</Link>
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {historyData.items.map((item) => (
                <div
                  key={item.id}
                  className="history-row flex items-center justify-between px-5 py-3.5"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-primary/8 border border-primary/15 flex items-center justify-center shrink-0">
                      <BrainCircuit className="w-4 h-4 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-mono text-sm font-semibold truncate max-w-xs">{item.text || "(empty)"}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{new Date(item.createdAt).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0 ml-4">
                    <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${modeColor[item.mode] ?? modeColor.auto}`}>
                      {item.mode}
                    </span>
                    <span className={`text-sm font-mono font-bold ${
                      item.confidence >= 0.8 ? "text-emerald-500" : item.confidence >= 0.5 ? "text-amber-500" : "text-red-500"
                    }`}>
                      {Math.round(item.confidence * 100)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { href: "/recognize", title: "New Recognition", desc: "Upload or draw a character to recognize", icon: Scan, color: "text-primary bg-primary/10" },
          { href: "/analytics", title: "View Analytics", desc: "Explore accuracy trends and character stats", icon: BarChart3, color: "text-purple-500 bg-purple-100 dark:bg-purple-900/20" },
          { href: "/models", title: "Model Library", desc: "Browse available OCR models and their specs", icon: Shapes, color: "text-emerald-500 bg-emerald-100 dark:bg-emerald-900/20" },
        ].map(({ href, title, desc, icon: Icon, color }) => (
          <Link key={href} href={href}>
            <Card className="action-card border hover:border-primary/30">
              <CardContent className="p-5 flex items-start gap-4">
                <div className={`p-2.5 rounded-xl shrink-0 ${color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-semibold text-sm">{title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{desc}</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
