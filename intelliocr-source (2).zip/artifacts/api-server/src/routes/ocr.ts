import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { recognitionsTable } from "@workspace/db";
import { RecognizeImageBody } from "@workspace/api-zod";

const router: IRouter = Router();

const modelList = [
  {
    id: "tesseract-v5",
    name: "Tesseract v5 (Browser)",
    description: "State-of-the-art LSTM-based OCR engine running directly in browser. Supports multi-language text recognition with high accuracy on printed and handwritten content.",
    accuracy: 0.94,
    supportedModes: ["auto", "word", "sentence", "letter"],
    version: "5.1.0",
  },
  {
    id: "digit-specialist",
    name: "Digit Specialist",
    description: "Optimized for single digit recognition (0–9). Uses character whitelist filtering to maximize accuracy on numeric handwriting. Ideal for forms and math notation.",
    accuracy: 0.98,
    supportedModes: ["digit"],
    version: "2.3.1",
  },
  {
    id: "alpha-specialist",
    name: "Alphabet Specialist",
    description: "Fine-tuned for isolated letter recognition (A–Z, a–z). Enhanced preprocessing pipeline reduces noise from scan artifacts and uneven pen pressure.",
    accuracy: 0.96,
    supportedModes: ["letter"],
    version: "1.8.0",
  },
  {
    id: "crnn-ctc",
    name: "CRNN + CTC",
    description: "Convolutional Recurrent Neural Network with Connectionist Temporal Classification. Excels at cursive handwriting and connected scripts. Best for full sentence recognition.",
    accuracy: 0.91,
    supportedModes: ["word", "sentence", "auto"],
    version: "3.0.2",
  },
];

router.post("/ocr/recognize", async (req, res): Promise<void> => {
  const parsed = RecognizeImageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const {
    imageData,
    mode,
    text,
    confidence,
    processingTimeMs,
    topPredictions,
    segments,
  } = parsed.data;

  if (!text) {
    res.status(400).json({ error: "No OCR text provided. Recognition must run in the browser first." });
    return;
  }

  try {
    const [saved] = await db
      .insert(recognitionsTable)
      .values({
        text: text,
        confidence: confidence ?? 0,
        mode: mode ?? "auto",
        processingTimeMs: processingTimeMs ?? 0,
        imageUrl: imageData.startsWith("data:") ? imageData : null,
        topPredictions: (topPredictions as Array<{ character: string; probability: number }>) ?? [],
        segments: (segments as Array<{ text: string; confidence: number; boundingBox: { x: number; y: number; width: number; height: number } }>) ?? [],
      })
      .returning();

    res.json({
      id: saved.id,
      text: saved.text,
      confidence: saved.confidence,
      mode: saved.mode,
      topPredictions: saved.topPredictions,
      processingTimeMs: saved.processingTimeMs,
      imageUrl: saved.imageUrl ?? null,
      heatmapUrl: saved.heatmapUrl ?? null,
      segments: saved.segments,
      createdAt: saved.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "OCR save failed");
    res.status(500).json({ error: "Failed to save recognition result" });
  }
});

router.get("/ocr/models", async (_req, res): Promise<void> => {
  res.json(modelList);
});

export default router;
