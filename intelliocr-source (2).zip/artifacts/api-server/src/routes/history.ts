import { Router, type IRouter } from "express";
import { db, recognitionsTable } from "@workspace/db";
import { eq, desc, count, sql } from "drizzle-orm";
import { ListHistoryQueryParams, GetHistoryItemParams, DeleteHistoryItemParams, ListHistoryResponse, GetHistoryItemResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/history", async (req, res): Promise<void> => {
  const parsed = ListHistoryQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { limit, offset, mode } = parsed.data;

  const whereClause = mode ? sql`${recognitionsTable.mode} = ${mode}` : undefined;

  const [items, totalResult] = await Promise.all([
    db
      .select()
      .from(recognitionsTable)
      .where(whereClause)
      .orderBy(desc(recognitionsTable.createdAt))
      .limit(limit ?? 20)
      .offset(offset ?? 0),
    db
      .select({ count: count() })
      .from(recognitionsTable)
      .where(whereClause),
  ]);

  const total = totalResult[0]?.count ?? 0;

  res.json(ListHistoryResponse.parse({
    items: items.map((r) => ({
      id: r.id,
      text: r.text,
      confidence: r.confidence,
      mode: r.mode,
      imageUrl: r.imageUrl ?? null,
      processingTimeMs: r.processingTimeMs,
      createdAt: r.createdAt.toISOString(),
    })),
    total,
  }));
});

router.get("/history/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetHistoryItemParams.safeParse({ id: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [item] = await db
    .select()
    .from(recognitionsTable)
    .where(eq(recognitionsTable.id, params.data.id));

  if (!item) {
    res.status(404).json({ error: "Not found" });
    return;
  }

  res.json(GetHistoryItemResponse.parse({
    id: item.id,
    text: item.text,
    confidence: item.confidence,
    mode: item.mode,
    imageUrl: item.imageUrl ?? null,
    processingTimeMs: item.processingTimeMs,
    createdAt: item.createdAt.toISOString(),
  }));
});

router.delete("/history/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DeleteHistoryItemParams.safeParse({ id: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(recognitionsTable)
    .where(eq(recognitionsTable.id, params.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
