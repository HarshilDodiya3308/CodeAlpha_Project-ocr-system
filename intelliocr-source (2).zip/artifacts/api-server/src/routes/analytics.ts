import { Router, type IRouter } from "express";
import { db, recognitionsTable } from "@workspace/db";
import { sql, count, avg } from "drizzle-orm";
import {
  GetAnalyticsSummaryResponse,
  GetCharacterFrequencyResponse,
  GetAccuracyTimelineResponse,
  GetModeBreakdownResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/analytics/summary", async (req, res): Promise<void> => {
  const [totals] = await db.select({
    total: count(),
    avgConf: avg(recognitionsTable.confidence),
    avgTime: avg(recognitionsTable.processingTimeMs),
  }).from(recognitionsTable);

  // Today count
  const [todayRow] = await db.select({ c: count() }).from(recognitionsTable).where(
    sql`DATE(${recognitionsTable.createdAt}) = CURRENT_DATE`
  );

  // Success rate (confidence >= 0.5)
  const [successRow] = await db.select({ c: count() }).from(recognitionsTable).where(
    sql`${recognitionsTable.confidence} >= 0.5`
  );

  // Top character — split text into individual chars, keep alphanumeric only
  const topCharRows = await db.execute(sql`
    SELECT ch, COUNT(*) as cnt
    FROM (
      SELECT regexp_split_to_table(text, '') as ch
      FROM recognitions
      WHERE text IS NOT NULL AND text != ''
    ) t
    WHERE ch ~ '^[A-Za-z0-9]$'
    GROUP BY ch
    ORDER BY cnt DESC
    LIMIT 1
  `);

  const total = totals.total;
  const topChar = (topCharRows.rows?.[0] as { ch: string })?.ch ?? "—";

  res.json(GetAnalyticsSummaryResponse.parse({
    totalRecognitions: total,
    averageConfidence: parseFloat(totals.avgConf as string ?? "0"),
    averageProcessingTimeMs: parseFloat(totals.avgTime as string ?? "0"),
    topCharacter: topChar,
    recognitionsToday: todayRow?.c ?? 0,
    successRate: total > 0 ? (successRow?.c ?? 0) / total : 0,
  }));
});

router.get("/analytics/character-frequency", async (req, res): Promise<void> => {
  const rows = await db.execute(sql`
    SELECT ch as character, COUNT(*) as count
    FROM (
      SELECT regexp_split_to_table(text, '') as ch
      FROM recognitions
      WHERE text IS NOT NULL AND text != ''
    ) t
    WHERE ch ~ '^[A-Za-z0-9]$'
    GROUP BY ch
    ORDER BY count DESC
    LIMIT 20
  `);

  const data = (rows.rows as Array<{ character: string; count: string }>).map((r) => ({
    character: r.character,
    count: parseInt(r.count, 10),
  }));

  res.json(GetCharacterFrequencyResponse.parse(data));
});

router.get("/analytics/accuracy-timeline", async (req, res): Promise<void> => {
  const rows = await db.execute(sql`
    SELECT
      DATE(created_at) as date,
      AVG(confidence) as avg_confidence,
      COUNT(*) as count
    FROM recognitions
    WHERE created_at >= NOW() - INTERVAL '30 days'
    GROUP BY DATE(created_at)
    ORDER BY date ASC
  `);

  const data = (rows.rows as Array<{ date: string; avg_confidence: string; count: string }>).map((r) => ({
    date: r.date,
    averageConfidence: parseFloat(r.avg_confidence),
    count: parseInt(r.count, 10),
  }));

  res.json(GetAccuracyTimelineResponse.parse(data));
});

router.get("/analytics/mode-breakdown", async (req, res): Promise<void> => {
  const rows = await db.execute(sql`
    SELECT mode, COUNT(*) as count
    FROM recognitions
    GROUP BY mode
    ORDER BY count DESC
  `);

  const data = (rows.rows as Array<{ mode: string; count: string }>).map((r) => ({
    mode: r.mode,
    count: parseInt(r.count, 10),
  }));

  res.json(GetModeBreakdownResponse.parse(data));
});

export default router;
