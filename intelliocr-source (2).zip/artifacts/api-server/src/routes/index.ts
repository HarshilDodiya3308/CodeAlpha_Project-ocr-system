import { Router, type IRouter } from "express";
import healthRouter from "./health";
import ocrRouter from "./ocr";
import historyRouter from "./history";
import analyticsRouter from "./analytics";

const router: IRouter = Router();

router.use(healthRouter);
router.use(ocrRouter);
router.use(historyRouter);
router.use(analyticsRouter);

export default router;
