/* Intelligent OCR System — Core JavaScript */

// ── Toast Notifications ───────────────────────────────────────────────────
const Toast = (() => {
  let container;
  function getContainer() {
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    return container;
  }

  function show(message, type = 'info', duration = 3500) {
    const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', info: 'fa-info-circle', warning: 'fa-exclamation-triangle' };
    const colors = { success: '#00ff88', error: '#ff3366', info: '#00f5ff', warning: '#ffcc00' };

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${icons[type] || icons.info}" style="color:${colors[type]};"></i><span>${message}</span>`;

    const c = getContainer();
    c.appendChild(toast);
    setTimeout(() => {
      toast.style.animation = 'slide-out 0.3s ease forwards';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  return { show, success: m => show(m, 'success'), error: m => show(m, 'error'), info: m => show(m, 'info') };
})();

// ── Particle Background ───────────────────────────────────────────────────
function initParticles() {
  const container = document.querySelector('.bg-particles');
  if (!container) return;
  const count = window.innerWidth < 600 ? 12 : 25;
  for (let i = 0; i < count; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const size = Math.random() * 4 + 2;
    p.style.cssText = `
      width: ${size}px; height: ${size}px;
      left: ${Math.random() * 100}%;
      bottom: ${Math.random() * -20}%;
      animation-duration: ${8 + Math.random() * 12}s;
      animation-delay: ${Math.random() * 8}s;
      background: ${Math.random() > 0.5 ? '#00f5ff' : '#bf00ff'};
      opacity: ${0.2 + Math.random() * 0.4};
    `;
    container.appendChild(p);
  }
}

// ── Sidebar Toggle ────────────────────────────────────────────────────────
function initSidebar() {
  const toggle = document.getElementById('sidebarToggle');
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebarOverlay');

  if (!toggle) return;

  toggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    if (overlay) overlay.style.display = sidebar.classList.contains('open') ? 'block' : 'none';
  });

  if (overlay) overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.style.display = 'none';
  });

  // Active nav link
  const path = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach(a => {
    a.classList.toggle('active', a.getAttribute('href') === path || (path === '/' && a.getAttribute('href') === '/'));
  });
}

// ── Health Check ──────────────────────────────────────────────────────────
async function checkHealth() {
  try {
    const r = await fetch('/ocr/health');
    const data = await r.json();
    const dot = document.getElementById('statusDot');
    const label = document.getElementById('statusLabel');
    if (dot && label) {
      if (data.demo_mode) {
        dot.className = 'status-dot demo';
        label.textContent = 'Demo Mode';
      } else {
        dot.className = 'status-dot';
        label.textContent = 'Models Loaded';
      }
    }

    const banner = document.getElementById('demoBanner');
    if (banner) banner.classList.toggle('hidden', !data.demo_mode);

    return data;
  } catch (e) {
    console.error('Health check failed', e);
  }
}

// ── Upload Page Logic ─────────────────────────────────────────────────────
function initUploadPage() {
  const zone = document.getElementById('uploadZone');
  const fileInput = document.getElementById('fileInput');
  const previewSection = document.getElementById('previewSection');
  const previewImg = document.getElementById('previewImg');
  const predictBtn = document.getElementById('predictBtn');
  const resultSection = document.getElementById('resultSection');
  const modeTabBtns = document.querySelectorAll('.mode-tab');
  const uploadTab = document.getElementById('tabUpload');
  const canvasTab = document.getElementById('tabCanvas');

  if (!zone) return;

  let currentFile = null;
  let currentMode = 'upload';
  let chart = null;

  // Mode tabs
  modeTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      modeTabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentMode = btn.dataset.mode;
      if (uploadTab) uploadTab.classList.toggle('hidden', currentMode !== 'upload');
      if (canvasTab) canvasTab.classList.toggle('hidden', currentMode !== 'canvas');
    });
  });

  // Drag-and-drop
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('drag-over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  });
  zone.addEventListener('click', () => fileInput && fileInput.click());
  if (fileInput) fileInput.addEventListener('change', e => { if (e.target.files[0]) handleFile(e.target.files[0]); });

  function handleFile(file) {
    if (file.size > 10 * 1024 * 1024) { Toast.error('File too large (max 10MB)'); return; }
    const valid = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/bmp'];
    if (!valid.includes(file.type)) { Toast.error('Invalid file type. Use PNG, JPG, or BMP.'); return; }
    currentFile = file;
    const url = URL.createObjectURL(file);
    if (previewImg) previewImg.src = url;
    if (previewSection) previewSection.classList.remove('hidden');
    Toast.success('Image loaded. Ready to predict!');
  }

  // Predict button
  if (predictBtn) {
    predictBtn.addEventListener('click', async () => {
      const isCanvas = currentMode === 'canvas';
      if (!isCanvas && !currentFile) { Toast.error('Please upload an image first'); return; }
      if (isCanvas && DrawingCanvas.isEmpty()) { Toast.error('Please draw a character first'); return; }

      const mode = document.querySelector('input[name="predictMode"]:checked')?.value || 'character';
      await runPrediction(isCanvas ? null : currentFile, isCanvas ? DrawingCanvas.getDataURL() : null, mode);
    });
  }

  async function runPrediction(file, dataUrl, mode) {
    showLoading(true);
    if (resultSection) resultSection.classList.add('hidden');

    const endpoint = { character: '/ocr/predict', word: '/ocr/predict/word', sentence: '/ocr/predict/sentence' }[mode] || '/ocr/predict';

    try {
      const fd = new FormData();
      if (file) {
        fd.append('image', file);
      } else {
        fd.append('image_data', dataUrl);
      }

      const res = await fetch(endpoint, { method: 'POST', body: fd });
      const data = await res.json();

      if (!data.success) { Toast.error(data.error || 'Prediction failed'); showLoading(false); return; }

      displayResult(data, mode);
      if (resultSection) resultSection.classList.remove('hidden');
      Toast.success('Prediction complete!');
    } catch (e) {
      Toast.error('Network error: ' + e.message);
    }
    showLoading(false);
  }

  function displayResult(data, mode) {
    if (mode === 'character') {
      const pred = data.prediction;

      // Character display
      const charEl = document.getElementById('resultChar');
      if (charEl) charEl.textContent = pred.character;

      // Confidence
      const conf = pred.confidence;
      const bar = document.getElementById('confBar');
      const confLabel = document.getElementById('confLabel');
      if (bar) {
        bar.style.width = '0%';
        setTimeout(() => { bar.style.width = conf + '%'; }, 50);
        bar.className = 'confidence-bar-fill ' + (conf >= 80 ? 'conf-high' : conf >= 50 ? 'conf-medium' : 'conf-low');
      }
      if (confLabel) confLabel.textContent = conf.toFixed(1) + '%';

      // Type badge
      const typeBadge = document.getElementById('charTypeBadge');
      if (typeBadge) typeBadge.textContent = pred.type.replace('_', ' ');

      // Top-5 chart
      if (pred.top5 && typeof Chart !== 'undefined') {
        const labels = pred.top5.map(x => x.label);
        const values = pred.top5.map(x => x.probability);
        const chartEl = document.getElementById('top5Chart');
        if (chartEl) {
          if (chart) chart.destroy();
          chart = new Chart(chartEl, {
            type: 'bar',
            data: {
              labels,
              datasets: [{
                label: 'Probability (%)',
                data: values,
                backgroundColor: labels.map((_, i) => i === 0 ? 'rgba(0,245,255,0.7)' : 'rgba(191,0,255,0.4)'),
                borderColor: labels.map((_, i) => i === 0 ? '#00f5ff' : '#bf00ff'),
                borderWidth: 1,
                borderRadius: 6,
              }]
            },
            options: {
              responsive: true,
              plugins: { legend: { display: false } },
              scales: {
                y: {
                  beginAtZero: true,
                  max: 100,
                  grid: { color: 'rgba(255,255,255,0.06)' },
                  ticks: { color: '#8888aa', font: { size: 11 } },
                },
                x: {
                  grid: { display: false },
                  ticks: { color: '#e8e8ff', font: { size: 13, weight: 'bold' } }
                }
              }
            }
          });
        }
      }

      // Processing steps
      const steps = document.getElementById('processingSteps');
      if (steps && data.previews) {
        steps.innerHTML = '';
        const labels = { original: 'Grayscale', blurred: 'Blur', threshold: 'Threshold', final: 'Normalised' };
        Object.entries(data.previews).forEach(([k, v]) => {
          steps.innerHTML += `<div class="step-card">
            <img src="${v}" alt="${k}">
            <span>${labels[k] || k}</span>
          </div>`;
        });
      }

      // Processing time
      const timeEl = document.getElementById('processTime');
      if (timeEl) timeEl.textContent = data.processing?.time_ms + 'ms';

    } else if (mode === 'word') {
      const wordEl = document.getElementById('resultWord');
      if (wordEl) wordEl.textContent = data.prediction.word || '';
      const charsEl = document.getElementById('resultChars');
      if (charsEl) {
        charsEl.innerHTML = (data.prediction.characters || []).map(c =>
          `<span class="char-pill" title="${c.type}: ${c.confidence.toFixed(1)}%">${c.character}</span>`
        ).join('');
      }
    } else if (mode === 'sentence') {
      const sentEl = document.getElementById('resultSentence');
      if (sentEl) sentEl.textContent = data.prediction.sentence || '';
    }

    // Demo mode note
    const demoNote = document.getElementById('demoNote');
    if (demoNote) demoNote.classList.toggle('hidden', !data.demo_mode);
  }

  function showLoading(show) {
    const spinner = document.getElementById('loadingSpinner');
    if (spinner) spinner.classList.toggle('hidden', !show);
    if (predictBtn) predictBtn.disabled = show;
  }
}

// ── Dashboard ─────────────────────────────────────────────────────────────
async function initDashboard() {
  const statsEl = {
    total: document.getElementById('statTotal'),
    avgConf: document.getElementById('statAvgConf'),
    digits: document.getElementById('statDigits'),
    letters: document.getElementById('statLetters'),
  };

  if (!statsEl.total) return;

  try {
    const [statsRes, histRes] = await Promise.all([
      fetch('/ocr/stats').then(r => r.json()),
      fetch('/ocr/history?limit=50').then(r => r.json()),
    ]);

    if (statsRes.success) {
      const s = statsRes.stats;
      if (statsEl.total) animateNumber(statsEl.total, s.total_predictions);
      if (statsEl.avgConf) animateNumber(statsEl.avgConf, s.average_confidence, 1);
      const digits = s.by_type?.digit || 0;
      const letters = (s.by_type?.uppercase_letter || 0) + (s.by_type?.lowercase_letter || 0);
      if (statsEl.digits) animateNumber(statsEl.digits, digits);
      if (statsEl.letters) animateNumber(statsEl.letters, letters);
    }

    if (histRes.success) {
      renderHistoryTable(histRes.history);
      renderConfChart(histRes.history);
    }
  } catch (e) {
    console.error('Dashboard load error', e);
    Toast.error('Failed to load dashboard data');
  }
}

function animateNumber(el, target, decimals = 0) {
  const start = 0;
  const duration = 1200;
  const startTime = performance.now();
  function step(now) {
    const progress = Math.min((now - startTime) / duration, 1);
    const val = start + (target - start) * easeOut(progress);
    el.textContent = decimals ? val.toFixed(decimals) : Math.floor(val);
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

function renderHistoryTable(history) {
  const tbody = document.getElementById('historyBody');
  if (!tbody) return;
  if (!history.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted" style="padding:32px">No predictions yet. Go to the Recognition page to get started!</td></tr>';
    return;
  }

  tbody.innerHTML = history.map(r => `
    <tr>
      <td><span class="char-cell">${r.character}</span></td>
      <td>
        <div style="display:flex;align-items:center;gap:8px;">
          <div class="confidence-bar-track" style="flex:1;height:6px;">
            <div class="confidence-bar-fill ${r.confidence >= 80 ? 'conf-high' : r.confidence >= 50 ? 'conf-medium' : 'conf-low'}" style="width:${r.confidence}%;height:100%;"></div>
          </div>
          <span style="min-width:44px;font-size:0.8rem">${r.confidence.toFixed(1)}%</span>
        </div>
      </td>
      <td><span class="char-type-badge">${r.type.replace('_', ' ')}</span></td>
      <td style="font-size:0.78rem;color:var(--text-secondary)">${new Date(r.timestamp).toLocaleString()}</td>
      <td>
        <button class="btn-glow btn-danger" style="padding:5px 12px;font-size:0.75rem;" onclick="deleteRecord(${r.id})">
          <i class="fas fa-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');
}

function renderConfChart(history) {
  const el = document.getElementById('confTrendChart');
  if (!el || !history.length || typeof Chart === 'undefined') return;
  const recent = history.slice(0, 20).reverse();
  new Chart(el, {
    type: 'line',
    data: {
      labels: recent.map(r => r.character),
      datasets: [{
        label: 'Confidence %',
        data: recent.map(r => r.confidence),
        fill: true,
        borderColor: '#00f5ff',
        backgroundColor: 'rgba(0,245,255,0.08)',
        tension: 0.4,
        pointBackgroundColor: '#00f5ff',
        pointBorderColor: '#00f5ff',
        pointRadius: 4,
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        y: { min: 0, max: 100, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#8888aa' } },
        x: { grid: { display: false }, ticks: { color: '#8888aa' } }
      }
    }
  });
}

async function deleteRecord(id) {
  try {
    const r = await fetch(`/ocr/history/${id}`, { method: 'DELETE' });
    const data = await r.json();
    if (data.success) {
      Toast.success('Record deleted');
      initDashboard();
    } else {
      Toast.error('Failed to delete record');
    }
  } catch (e) {
    Toast.error('Error: ' + e.message);
  }
}

// ── API Docs Toggle ───────────────────────────────────────────────────────
function initApiDocs() {
  document.querySelectorAll('.endpoint-header').forEach(header => {
    header.addEventListener('click', () => {
      const body = header.nextElementSibling;
      if (body) body.classList.toggle('open');
      const icon = header.querySelector('.toggle-icon');
      if (icon) icon.classList.toggle('fa-chevron-down');
      if (icon) icon.classList.toggle('fa-chevron-up');
    });
  });

  // Try it buttons
  document.querySelectorAll('[data-try]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const endpoint = btn.dataset.try;
      const output = btn.closest('.endpoint-body').querySelector('.try-output');
      if (!output) return;
      output.textContent = 'Loading…';
      try {
        const r = await fetch(endpoint);
        const data = await r.json();
        output.textContent = JSON.stringify(data, null, 2);
      } catch (e) {
        output.textContent = 'Error: ' + e.message;
      }
    });
  });
}

// ── Init ──────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initParticles();
  initSidebar();
  checkHealth();
  initUploadPage();
  initDashboard();
  initApiDocs();

  // Canvas drawing
  if (document.getElementById('drawCanvas')) {
    DrawingCanvas.init('drawCanvas');
    const clearBtn = document.getElementById('clearCanvas');
    const undoBtn = document.getElementById('undoCanvas');
    const brushRange = document.getElementById('brushSize');
    const brushLabel = document.getElementById('brushSizeLabel');

    if (clearBtn) clearBtn.addEventListener('click', () => { DrawingCanvas.clearCanvas(); Toast.info('Canvas cleared'); });
    if (undoBtn) undoBtn.addEventListener('click', DrawingCanvas.undo);
    if (brushRange) {
      brushRange.addEventListener('input', e => {
        DrawingCanvas.setBrushSize(e.target.value);
        if (brushLabel) brushLabel.textContent = e.target.value + 'px';
      });
    }
  }
});
