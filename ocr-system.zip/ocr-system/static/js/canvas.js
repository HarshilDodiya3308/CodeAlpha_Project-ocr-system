/* Drawing Canvas Logic */

const DrawingCanvas = (() => {
  let canvas, ctx;
  let isDrawing = false;
  let lastX = 0, lastY = 0;
  let brushSize = 18;
  let brushColor = '#ffffff';
  let history = [];
  let historyStep = -1;

  function init(canvasId) {
    canvas = document.getElementById(canvasId);
    if (!canvas) return;
    ctx = canvas.getContext('2d', { willReadFrequently: true });

    // Set canvas size based on container
    resizeCanvas();
    clearCanvas();

    canvas.addEventListener('mousedown', startDraw);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDraw);
    canvas.addEventListener('mouseleave', stopDraw);

    // Touch events
    canvas.addEventListener('touchstart', e => {
      e.preventDefault();
      const t = e.touches[0];
      const rect = canvas.getBoundingClientRect();
      startDraw({ offsetX: t.clientX - rect.left, offsetY: t.clientY - rect.top });
    }, { passive: false });

    canvas.addEventListener('touchmove', e => {
      e.preventDefault();
      const t = e.touches[0];
      const rect = canvas.getBoundingClientRect();
      draw({ offsetX: t.clientX - rect.left, offsetY: t.clientY - rect.top });
    }, { passive: false });

    canvas.addEventListener('touchend', stopDraw);
    saveHistory();
  }

  function resizeCanvas() {
    const container = canvas.parentElement;
    const size = Math.min(container.clientWidth || 380, 380);
    canvas.width = size;
    canvas.height = size;
  }

  function startDraw(e) {
    isDrawing = true;
    [lastX, lastY] = [e.offsetX, e.offsetY];
    ctx.beginPath();
    ctx.arc(lastX, lastY, brushSize / 2, 0, Math.PI * 2);
    ctx.fillStyle = brushColor;
    ctx.fill();
  }

  function draw(e) {
    if (!isDrawing) return;
    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(e.offsetX, e.offsetY);
    ctx.strokeStyle = brushColor;
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
    [lastX, lastY] = [e.offsetX, e.offsetY];
  }

  function stopDraw() {
    if (isDrawing) {
      isDrawing = false;
      saveHistory();
    }
  }

  function clearCanvas() {
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    saveHistory();
  }

  function saveHistory() {
    historyStep++;
    if (historyStep < history.length) history.length = historyStep;
    history.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
    if (history.length > 30) { history.shift(); historyStep--; }
  }

  function undo() {
    if (historyStep > 0) {
      historyStep--;
      ctx.putImageData(history[historyStep], 0, 0);
    }
  }

  function setBrushSize(size) { brushSize = parseInt(size); }
  function setBrushColor(color) { brushColor = color; }

  function getDataURL() {
    return canvas.toDataURL('image/png');
  }

  function isEmpty() {
    const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    for (let i = 0; i < data.length; i += 4) {
      if (data[i] > 5 || data[i + 1] > 5 || data[i + 2] > 5) return false;
    }
    return true;
  }

  return { init, clearCanvas, undo, setBrushSize, setBrushColor, getDataURL, isEmpty };
})();
