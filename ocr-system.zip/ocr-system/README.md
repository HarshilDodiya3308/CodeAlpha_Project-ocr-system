# Intelligent OCR System

Handwritten digit (MNIST) and alphabet (EMNIST) recognition with a 3D glassmorphism dark-theme UI built on Python Flask.

---

## Quick Start (VS Code)

### 1 — Prerequisites

| Tool | Version |
|------|---------|
| Python | 3.10 – 3.12 |
| pip | any recent |

### 2 — Clone / unzip the project

```bash
unzip ocr-system.zip -d ocr-system
cd ocr-system
```

### 3 — Create a virtual environment

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows
.venv\Scripts\activate
```

### 4 — Install dependencies

```bash
pip install -r requirements.txt
```

> **TensorFlow (optional)** — only needed for real CNN inference.
> The app runs in **Demo Mode** without it, showing image-aware simulated predictions.
> To enable real models:
> ```bash
> pip install tensorflow==2.16.1 scikit-image==0.22.0
> python models/train_model.py
> ```

### 5 — Run the server

```bash
python app.py
```

Open http://localhost:5000 in your browser.

---

## VS Code — recommended extensions

- **Python** (ms-python.python)
- **Pylance** (ms-python.vscode-pylance)
- **REST Client** (humao.rest-client) — test the API endpoints in `.http` files

### VS Code launch config

Paste this into `.vscode/launch.json` to use F5:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Flask OCR",
      "type": "python",
      "request": "launch",
      "program": "${workspaceFolder}/app.py",
      "env": { "PORT": "5000", "FLASK_ENV": "development" },
      "console": "integratedTerminal"
    }
  ]
}
```

---

## Project structure

```
ocr-system/
├── app.py                  ← Flask entry point + DB model
├── config.py               ← Configuration (PORT, DB path, etc.)
├── requirements.txt
├── api/
│   ├── routes.py           ← All REST endpoints (/ocr/*)
│   └── serializers.py      ← JSON response builders
├── models/
│   ├── model_architecture.py  ← CNN definition
│   └── train_model.py         ← Training script (needs TensorFlow)
├── static/
│   ├── css/style.css       ← Glassmorphism dark theme
│   └── js/
│       ├── main.js         ← UI logic, API calls, charts
│       └── canvas.js       ← Drawing pad
├── templates/
│   ├── base.html           ← Layout + sidebar
│   ├── index.html          ← Predict page
│   ├── dashboard.html      ← Analytics dashboard
│   ├── api_docs.html       ← Interactive API reference
│   └── about.html          ← About page
└── database/
    └── ocr.db              ← SQLite DB (auto-created on first run)
```

---

## REST API reference

Base URL: `http://localhost:5000`

| Method | Path | Description |
|--------|------|-------------|
| GET | `/ocr/health` | System status + model flags |
| POST | `/ocr/predict` | Single character prediction |
| POST | `/ocr/predict/word` | Word segmentation + prediction |
| POST | `/ocr/predict/sentence` | Sentence segmentation + prediction |
| GET | `/ocr/history` | Prediction history (`?limit=50`) |
| GET | `/ocr/stats` | Aggregated statistics |
| DELETE | `/ocr/history/:id` | Delete a record |

### Upload via cURL

```bash
curl -X POST http://localhost:5000/ocr/predict \
  -F "image=@/path/to/digit.png"
```

---

## Training real models

1. Install TensorFlow: `pip install tensorflow==2.16.1`
2. Run: `python models/train_model.py`
3. Models are saved to `models/saved/`. The app detects them on the next request and switches out of Demo Mode automatically.

---

## Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| PORT | 5000 | HTTP port |
| FLASK_ENV | development | `development` or `production` |
| SECRET_KEY | dev-secret | Flask session secret |

Create a `.env` file (or set variables directly) before running in production.
