import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "ocr-system-secret-2026")
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "database", "ocr.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10 MB
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "bmp"}
    DIGIT_MODEL_PATH = os.path.join(BASE_DIR, "models", "digit_model.h5")
    LETTER_MODEL_PATH = os.path.join(BASE_DIR, "models", "letter_model.h5")
    COMBINED_MODEL_PATH = os.path.join(BASE_DIR, "models", "combined_model.h5")
    HISTORY_LIMIT = 50
    PORT = int(os.environ.get("PORT", 5000))
    DEBUG = os.environ.get("DEBUG", "True") == "True"
