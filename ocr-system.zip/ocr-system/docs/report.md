# Technical Report — Intelligent OCR System

## 1. Introduction

This project implements a production-ready Optical Character Recognition (OCR) system for handwritten digits (0–9) and alphabets (A–Z, a–z) using deep learning. The system integrates a REST API, SQLite persistence, and a glassmorphism 3D web interface.

## 2. Architecture

### 2.1 System Layers

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.11, Flask 3, Flask-SQLAlchemy |
| Deep Learning | TensorFlow 2.x, Keras CNN |
| Image Processing | Pillow, NumPy, scikit-image |
| Frontend | HTML5, CSS3 (Glassmorphism), JavaScript ES6+ |
| Database | SQLite via SQLAlchemy |
| Visualisation | Chart.js 4 |

### 2.2 CNN Architecture

The model follows a three-block convolutional design:

```
Input(28×28×1) → Conv2D(32)→BN→Pool→Drop →
                 Conv2D(64)→BN→Pool→Drop →
                 Conv2D(128)→BN→Drop →
                 Flatten→Dense(512)→Drop→Dense(256)→Softmax(47)
```

Total trainable parameters: ~827,000

### 2.3 Image Processing Pipeline

1. Greyscale conversion
2. Gaussian blur (1px radius)
3. Mean-based adaptive thresholding
4. Resize to 28×28 (LANCZOS)
5. Pixel normalisation [0.0–1.0]
6. Reshape to (1,28,28,1) for Keras input

## 3. Datasets

- **MNIST**: 70,000 handwritten digit images, 28×28 greyscale
- **EMNIST Balanced**: 112,800 handwritten character images, 47 classes

## 4. API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/health | System health and model status |
| POST | /api/predict | Single character prediction |
| POST | /api/predict/word | Word-level OCR |
| POST | /api/predict/sentence | Sentence-level OCR |
| GET | /api/history | Prediction history |
| GET | /api/stats | Aggregate statistics |
| DELETE | /api/history/:id | Remove record |

## 5. Running the System

```bash
# Install dependencies
pip install -r requirements.txt

# Run in development mode
python app.py

# Run with Gunicorn (production)
gunicorn --bind 0.0.0.0:5000 --workers 2 app:app

# Train models (requires TensorFlow)
pip install tensorflow
python models/train_model.py --mode combined
```

## 6. Demo Mode

When no trained models are present, the system automatically enters Demo Mode and returns simulated predictions with realistic confidence distributions. This allows full UI and API testing without requiring TensorFlow or trained weights.

## 7. Performance Targets

| Model | Dataset | Target Accuracy |
|-------|---------|----------------|
| Digit | MNIST | ≥99% |
| Combined | EMNIST Balanced | ≥88% |
