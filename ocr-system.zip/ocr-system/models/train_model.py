"""
Train CNN models on MNIST (digits) and EMNIST Balanced (letters + digits).

Usage:
    python models/train_model.py --mode digits   # Train digit model only
    python models/train_model.py --mode letters  # Train letter model only
    python models/train_model.py --mode combined # Train combined model (default)
    python models/train_model.py --mode all      # Train all three
"""

import os
import sys
import argparse
import numpy as np

MODELS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(MODELS_DIR, ".."))

try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras.preprocessing.image import ImageDataGenerator
    from model_architecture import (
        get_digit_model, get_letter_model, get_combined_model,
        NUM_DIGIT_CLASSES, NUM_LETTER_CLASSES, NUM_COMBINED_CLASSES,
    )
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False
    print("TensorFlow not available. Install with: pip install tensorflow")


# ── EMNIST Balanced label map ────────────────────────────────────────────────
# 0-9 → digits, 10-35 → A-Z, 36-46 → a-z subset (EMNIST Balanced has 47 classes)
EMNIST_LABELS = (
    [str(i) for i in range(10)]
    + [chr(c) for c in range(ord("A"), ord("Z") + 1)]
    + ["a", "b", "d", "e", "f", "g", "h", "n", "q", "r", "t"]
)


def augmentation_gen(horizontal_flip=False):
    return ImageDataGenerator(
        rotation_range=15,
        width_shift_range=0.1,
        height_shift_range=0.1,
        zoom_range=0.1,
        horizontal_flip=horizontal_flip,
    )


def load_mnist():
    (x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()
    x_train = x_train.astype("float32") / 255.0
    x_test = x_test.astype("float32") / 255.0
    x_train = x_train[..., np.newaxis]
    x_test = x_test[..., np.newaxis]
    return (x_train, y_train), (x_test, y_test)


def load_emnist_balanced():
    """
    Load EMNIST Balanced via tensorflow_datasets or from cached .npz.
    Falls back to a synthetic placeholder if neither is available.
    """
    try:
        import tensorflow_datasets as tfds
        ds_train, ds_test = tfds.load(
            "emnist/balanced",
            split=["train", "test"],
            as_supervised=True,
        )
        def prep(img, label):
            img = tf.cast(img, tf.float32) / 255.0
            img = tf.image.rot90(img, k=3)
            img = tf.image.flip_left_right(img)
            return img, label

        x_train, y_train, x_test, y_test = [], [], [], []
        for img, lbl in ds_train.map(prep):
            x_train.append(img.numpy())
            y_train.append(lbl.numpy())
        for img, lbl in ds_test.map(prep):
            x_test.append(img.numpy())
            y_test.append(lbl.numpy())

        return (np.array(x_train), np.array(y_train)), (np.array(x_test), np.array(y_test))
    except Exception as e:
        print(f"EMNIST load failed ({e}). Generating synthetic data for smoke-test.")
        n_train, n_test = 1000, 200
        x_train = np.random.rand(n_train, 28, 28, 1).astype("float32")
        y_train = np.random.randint(0, NUM_COMBINED_CLASSES, n_train)
        x_test = np.random.rand(n_test, 28, 28, 1).astype("float32")
        y_test = np.random.randint(0, NUM_COMBINED_CLASSES, n_test)
        return (x_train, y_train), (x_test, y_test)


def train_digit_model(epochs=15, batch_size=128):
    print("\n=== Training Digit Model (MNIST) ===")
    (x_train, y_train), (x_test, y_test) = load_mnist()

    model = get_digit_model()
    model.summary()

    aug = augmentation_gen(horizontal_flip=True)
    callbacks = [
        keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True),
        keras.callbacks.ReduceLROnPlateau(patience=3, factor=0.5, verbose=1),
        keras.callbacks.ModelCheckpoint(
            os.path.join(MODELS_DIR, "digit_model.h5"),
            save_best_only=True, verbose=1,
        ),
    ]

    model.fit(
        aug.flow(x_train, y_train, batch_size=batch_size),
        epochs=epochs,
        validation_data=(x_test, y_test),
        callbacks=callbacks,
    )
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\nDigit model  →  test accuracy: {acc:.4f}  |  loss: {loss:.4f}")
    return model


def train_letter_model(epochs=20, batch_size=128):
    print("\n=== Training Letter Model (EMNIST) ===")
    (x_train, y_train), (x_test, y_test) = load_emnist_balanced()

    from model_architecture import get_letter_model
    model = get_letter_model()
    model.summary()

    callbacks = [
        keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True),
        keras.callbacks.ReduceLROnPlateau(patience=3, factor=0.5, verbose=1),
        keras.callbacks.ModelCheckpoint(
            os.path.join(MODELS_DIR, "letter_model.h5"),
            save_best_only=True, verbose=1,
        ),
    ]

    model.fit(
        x_train, y_train,
        batch_size=batch_size,
        epochs=epochs,
        validation_data=(x_test, y_test),
        callbacks=callbacks,
    )
    return model


def train_combined_model(epochs=20, batch_size=128):
    print("\n=== Training Combined Model (EMNIST Balanced — 47 classes) ===")
    (x_train, y_train), (x_test, y_test) = load_emnist_balanced()

    model = get_combined_model()
    model.summary()

    callbacks = [
        keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True),
        keras.callbacks.ReduceLROnPlateau(patience=3, factor=0.5, verbose=1),
        keras.callbacks.ModelCheckpoint(
            os.path.join(MODELS_DIR, "combined_model.h5"),
            save_best_only=True, verbose=1,
        ),
    ]

    model.fit(
        x_train, y_train,
        batch_size=batch_size,
        epochs=epochs,
        validation_data=(x_test, y_test),
        callbacks=callbacks,
    )
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\nCombined model  →  test accuracy: {acc:.4f}  |  loss: {loss:.4f}")
    return model


if __name__ == "__main__":
    if not TF_AVAILABLE:
        sys.exit(1)

    parser = argparse.ArgumentParser(description="Train OCR models")
    parser.add_argument(
        "--mode",
        choices=["digits", "letters", "combined", "all"],
        default="combined",
    )
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=128)
    args = parser.parse_args()

    if args.mode in ("digits", "all"):
        train_digit_model(args.epochs, args.batch_size)
    if args.mode in ("letters", "all"):
        train_letter_model(args.epochs, args.batch_size)
    if args.mode in ("combined", "all"):
        train_combined_model(args.epochs, args.batch_size)

    print("\nTraining complete. Model files saved in models/")
