"""
CNN Architecture for OCR — Digits (0-9) and Letters (A-Z, a-z).
Requires TensorFlow/Keras. Falls back gracefully when not installed.
"""

try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False


NUM_DIGIT_CLASSES = 10    # 0-9
NUM_LETTER_CLASSES = 26   # A-Z (case-insensitive for EMNIST Balanced mapping)
NUM_COMBINED_CLASSES = 47 # EMNIST Balanced: 10 digits + 37 letters


def build_cnn(num_classes: int, input_shape=(28, 28, 1)):
    """Build the CNN architecture described in the project spec."""
    if not TF_AVAILABLE:
        raise RuntimeError("TensorFlow is not installed. Run: pip install tensorflow")

    model = keras.Sequential([
        keras.Input(shape=input_shape),

        # Block 1
        layers.Conv2D(32, (3, 3), activation="relu", padding="same"),
        layers.BatchNormalization(),
        layers.MaxPooling2D((2, 2)),
        layers.Dropout(0.25),

        # Block 2
        layers.Conv2D(64, (3, 3), activation="relu", padding="same"),
        layers.BatchNormalization(),
        layers.MaxPooling2D((2, 2)),
        layers.Dropout(0.25),

        # Block 3
        layers.Conv2D(128, (3, 3), activation="relu", padding="same"),
        layers.BatchNormalization(),
        layers.Dropout(0.25),

        # Classifier
        layers.Flatten(),
        layers.Dense(512, activation="relu"),
        layers.Dropout(0.5),
        layers.Dense(256, activation="relu"),
        layers.Dense(num_classes, activation="softmax"),
    ], name=f"ocr_cnn_{num_classes}cls")

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def get_digit_model():
    return build_cnn(NUM_DIGIT_CLASSES)


def get_letter_model():
    return build_cnn(NUM_LETTER_CLASSES)


def get_combined_model():
    return build_cnn(NUM_COMBINED_CLASSES)


if __name__ == "__main__":
    if TF_AVAILABLE:
        m = get_combined_model()
        m.summary()
    else:
        print("TensorFlow not available.")
