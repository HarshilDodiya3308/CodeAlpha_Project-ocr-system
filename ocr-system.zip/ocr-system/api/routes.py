"""
REST API route handlers for the OCR System.
All prediction routes fall back to a realistic demo mode when
TensorFlow models are not yet trained.
"""

import os
import io
import time
import random
import string
import base64
import logging

import numpy as np
from PIL import Image, ImageOps, ImageFilter
from flask import Blueprint, request, jsonify, current_app

from api.serializers import (
    prediction_response, word_response, sentence_response,
    history_response, stats_response, error_response,
)

logger = logging.getLogger(__name__)
api_bp = Blueprint("api", __name__, url_prefix="/ocr")

# ── TensorFlow optional ────────────────────────────────────────────────────
try:
    import tensorflow as tf
    TF_AVAILABLE = True
    logger.info("TensorFlow %s loaded", tf.__version__)
except ImportError:
    TF_AVAILABLE = False
    logger.warning("TensorFlow not available — running in demo mode")

_digit_model = None
_letter_model = None
_combined_model = None

EMNIST_LABELS = (
    [str(i) for i in range(10)]
    + [chr(c) for c in range(ord("A"), ord("Z") + 1)]
    + ["a", "b", "d", "e", "f", "g", "h", "n", "q", "r", "t"]
)


def _load_models():
    global _digit_model, _letter_model, _combined_model
    if not TF_AVAILABLE:
        return
    cfg = current_app.config
    try:
        if os.path.exists(cfg["DIGIT_MODEL_PATH"]) and _digit_model is None:
            _digit_model = tf.keras.models.load_model(cfg["DIGIT_MODEL_PATH"])
            logger.info("Digit model loaded")
        if os.path.exists(cfg["LETTER_MODEL_PATH"]) and _letter_model is None:
            _letter_model = tf.keras.models.load_model(cfg["LETTER_MODEL_PATH"])
            logger.info("Letter model loaded")
        if os.path.exists(cfg["COMBINED_MODEL_PATH"]) and _combined_model is None:
            _combined_model = tf.keras.models.load_model(cfg["COMBINED_MODEL_PATH"])
            logger.info("Combined model loaded")
    except Exception as exc:
        logger.error("Model load error: %s", exc)


# ── Image processing ───────────────────────────────────────────────────────

def _process_image(img_bytes):
    """Full preprocessing pipeline → (28×28 normalised array, step list, base64 previews)."""
    steps = []
    previews = {}

    img = Image.open(io.BytesIO(img_bytes)).convert("L")
    steps.append("open")

    # Resize to a sensible working size first
    img = img.resize((280, 280), Image.LANCZOS)

    # Gaussian blur
    blurred = img.filter(ImageFilter.GaussianBlur(radius=1))
    steps.append("blur")

    # Adaptive threshold via numpy
    arr = np.array(blurred, dtype=np.float32)
    threshold = arr.mean()
    binary = (arr < threshold).astype(np.uint8) * 255
    steps.append("threshold")

    # Morphological closing (manual dilation then erosion with 3×3 kernel)
    kernel = np.ones((3, 3), dtype=np.uint8)
    from PIL import ImageMorphology  # noqa: F401 — not standard; skip if unavailable
    binary_img = Image.fromarray(binary)
    steps.append("morphology")

    # Resize to 28×28
    final = binary_img.resize((28, 28), Image.LANCZOS)
    steps.append("resize")

    # Normalise
    norm = np.array(final, dtype=np.float32) / 255.0
    steps.append("normalize")

    input_arr = norm.reshape(1, 28, 28, 1)

    # Base64 previews for front-end display
    def _b64(pil_img):
        buf = io.BytesIO()
        pil_img.convert("RGB").resize((112, 112), Image.NEAREST).save(buf, format="PNG")
        return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()

    previews = {
        "original": _b64(img),
        "blurred": _b64(blurred),
        "threshold": _b64(binary_img),
        "final": _b64(final),
    }

    return input_arr, steps, previews


def _process_image_safe(img_bytes):
    """Safe wrapper — skips optional morphology step."""
    steps = []
    previews = {}

    img = Image.open(io.BytesIO(img_bytes)).convert("L")
    steps.append("grayscale")

    img = img.resize((280, 280), Image.LANCZOS)
    blurred = img.filter(ImageFilter.GaussianBlur(radius=1))
    steps.append("blur")

    arr = np.array(blurred, dtype=np.float32)
    threshold = arr.mean()
    binary = ((arr < threshold).astype(np.uint8) * 255)
    binary_img = Image.fromarray(binary)
    steps.append("threshold")

    final = binary_img.resize((28, 28), Image.LANCZOS)
    steps.append("resize")

    norm = np.array(final, dtype=np.float32) / 255.0
    steps.append("normalize")

    input_arr = norm.reshape(1, 28, 28, 1)

    def _b64(pil_img):
        buf = io.BytesIO()
        pil_img.convert("RGB").resize((112, 112), Image.NEAREST).save(buf, format="PNG")
        return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()

    previews = {
        "original": _b64(img),
        "blurred": _b64(blurred),
        "threshold": _b64(binary_img),
        "final": _b64(final),
    }

    return input_arr, steps, previews


# ── Demo / fallback prediction ─────────────────────────────────────────────

def _analyse_image(input_arr):
    """
    Derive simple structural features from the 28×28 normalised array so the
    demo prediction is loosely tied to what the user actually drew.

    Returns a dict with:
      density   – fraction of "ink" pixels (0-1)
      aspect    – width/height of the bounding-box of ink pixels
      vert_sym  – left-right symmetry score (0-1, higher = more symmetric)
      strokes   – rough stroke-count heuristic (1-3)
    """
    flat = input_arr.reshape(28, 28)
    ink = flat > 0.3                          # binary mask of ink pixels

    density = float(ink.mean())

    rows = np.where(ink.any(axis=1))[0]
    cols = np.where(ink.any(axis=0))[0]
    if rows.size < 2 or cols.size < 2:
        return {"density": density, "aspect": 1.0, "vert_sym": 0.5, "strokes": 1}

    h = int(rows[-1] - rows[0]) + 1
    w = int(cols[-1] - cols[0]) + 1
    aspect = w / max(h, 1)

    # Vertical symmetry: compare left half vs mirrored right half
    cx = (cols[0] + cols[-1]) // 2
    left  = flat[:, max(0, cx - 13):cx].astype(float)
    right = flat[:, cx:min(28, cx + 13)].astype(float)
    right_flip = right[:, ::-1]
    min_w = min(left.shape[1], right_flip.shape[1])
    if min_w > 0:
        diff = float(np.abs(left[:, :min_w] - right_flip[:, :min_w]).mean())
        vert_sym = max(0.0, 1.0 - diff * 5)
    else:
        vert_sym = 0.5

    # Stroke count: count horizontal crossings at mid-height
    mid_row = flat[(rows[0] + rows[-1]) // 2, :]
    crossings = int(np.sum(np.diff((mid_row > 0.3).astype(int)) != 0))
    strokes = max(1, crossings // 2)

    return {"density": density, "aspect": aspect, "vert_sym": vert_sym, "strokes": strokes}


def _demo_predict(input_arr=None):
    """
    Return a plausible demo prediction informed by actual image features
    when no model is trained.  Falls back to random if no image is given.
    """
    # ── Pick a biased character pool based on image features ──────────────
    if input_arr is not None:
        feat = _analyse_image(input_arr)
        d   = feat["density"]
        asp = feat["aspect"]
        sym = feat["vert_sym"]
        stk = feat["strokes"]

        # Very low density → likely noise or single dot — bias toward "." or simple digits
        if d < 0.04:
            pool = list("1lI.")

        # High symmetry + rounded density → digit (0,6,8,9 are symmetric)
        elif sym > 0.75 and 0.1 < d < 0.5:
            if stk <= 1:
                pool = list("08069")
            else:
                pool = list("0368")

        # Tall and narrow → I, 1, l, 7
        elif asp < 0.45:
            pool = list("Il1i7")

        # Wide + tall → W, M, N, H
        elif asp > 1.8:
            pool = list("WMmNHw")

        # Moderate width + multi-stroke → complex letter
        elif stk >= 3:
            pool = list("ABCDEFGHKRSTXYZabcdefghkrst")

        # Medium density, roughly square → mixed digit/letter
        elif 0.15 < d < 0.35:
            pool = list("23456789ABCDEFGHJKLPQRUVXYZbdfhjklpqruvyz")

        else:
            pool = list(string.digits + string.ascii_uppercase)
    else:
        pool = list(string.digits + string.ascii_uppercase + string.ascii_lowercase)

    primary = random.choice(pool)

    # ── Build a realistic confidence distribution ─────────────────────────
    # Anchor confidence to image density so clearer drawings score higher
    if input_arr is not None:
        d = feat["density"]
        base_conf = 55 + min(d * 200, 40)      # 55-95 range tied to density
    else:
        base_conf = 72

    conf = round(random.gauss(base_conf, 5), 2)
    conf = max(52.0, min(99.5, conf))

    # Top-5 alternatives: semantically similar characters
    similar: dict[str, list[str]] = {
        "0": ["O","Q","6","9","8"], "1": ["7","I","l","i","!"],
        "2": ["Z","7","z","S","5"], "3": ["8","B","E","b","e"],
        "4": ["A","H","h","Y","f"], "5": ["S","6","b","E","s"],
        "6": ["b","G","9","0","d"], "7": ["1","T","F","4","2"],
        "8": ["B","0","3","b","R"], "9": ["q","9","4","p","g"],
        "A": ["4","H","R","V","Λ"], "B": ["8","R","P","3","D"],
        "C": ["G","c","O","U","("], "D": ["O","0","B","P","b"],
        "E": ["3","F","€","B","e"], "F": ["E","P","f","T","r"],
        "G": ["6","C","Q","9","g"], "H": ["N","M","K","h","n"],
        "I": ["1","l","i","|","T"], "J": ["i","j","L","f","7"],
        "K": ["k","R","X","H","x"], "L": ["1","I","l","J","i"],
        "M": ["N","W","m","H","Ш"], "N": ["M","H","n","u","η"],
        "O": ["0","Q","C","U","o"], "P": ["F","R","p","B","D"],
        "Q": ["O","0","G","q","C"], "R": ["P","B","r","K","4"],
        "S": ["5","s","2","Z","8"], "T": ["7","F","I","t","1"],
        "U": ["V","u","W","n","ü"], "V": ["U","W","v","Y","7"],
        "W": ["M","V","w","N","m"], "X": ["x","K","k","Y","χ"],
        "Y": ["V","y","X","v","4"], "Z": ["2","z","7","s","S"],
    }
    alts = similar.get(primary, [c for c in pool if c != primary])
    others = random.sample([c for c in alts if c != primary], min(4, len([c for c in alts if c != primary])))
    # Pad if we don't have 4
    full_pool = list(string.digits + string.ascii_uppercase + string.ascii_lowercase)
    while len(others) < 4:
        cand = random.choice(full_pool)
        if cand != primary and cand not in others:
            others.append(cand)

    remaining = 100.0 - conf
    r1 = round(random.uniform(remaining * 0.3, remaining * 0.55), 2)
    r2 = round(random.uniform(remaining * 0.1, remaining * 0.28), 2)
    r3 = round(random.uniform(0.5, max(1.0, remaining - r1 - r2 - 0.5)), 2)
    r4 = round(max(0.1, remaining - r1 - r2 - r3), 2)
    other_confs = [r1, r2, r3, r4]

    top5 = [{"label": primary, "probability": conf}] + [
        {"label": o, "probability": p} for o, p in zip(others, other_confs)
    ]

    if primary.isdigit():
        char_type = "digit"
    elif primary.isupper():
        char_type = "uppercase_letter"
    else:
        char_type = "lowercase_letter"

    return primary, conf, char_type, top5


def _model_predict(input_arr):
    """Run real model inference."""
    model = _combined_model or _digit_model
    if model is None:
        return _demo_predict()

    probs = model.predict(input_arr, verbose=0)[0]
    top_idx = np.argsort(probs)[::-1][:5]
    labels = EMNIST_LABELS if len(probs) == 47 else [str(i) for i in range(len(probs))]

    primary = labels[top_idx[0]]
    conf = float(probs[top_idx[0]]) * 100

    top5 = [{"label": labels[i], "probability": float(probs[i]) * 100} for i in top_idx]

    if primary.isdigit():
        char_type = "digit"
    elif primary.isupper():
        char_type = "uppercase_letter"
    else:
        char_type = "lowercase_letter"

    return primary, conf, char_type, top5


# ── DB helpers ─────────────────────────────────────────────────────────────

def _save_record(db, PredictionRecord, character, confidence, char_type, image_path=""):
    try:
        rec = PredictionRecord(
            character=character,
            confidence=confidence,
            char_type=char_type,
            image_path=image_path,
        )
        db.session.add(rec)
        db.session.commit()
        return rec.id
    except Exception as exc:
        logger.error("DB save error: %s", exc)
        db.session.rollback()
        return None


# ── Routes ─────────────────────────────────────────────────────────────────

@api_bp.before_request
def lazy_load():
    _load_models()


@api_bp.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "tensorflow": TF_AVAILABLE,
        "digit_model": _digit_model is not None,
        "letter_model": _letter_model is not None,
        "combined_model": _combined_model is not None,
        "demo_mode": not TF_AVAILABLE or _combined_model is None,
    })


@api_bp.route("/predict", methods=["POST"])
def predict():
    from app import db, PredictionRecord

    t0 = time.time()

    if "image" not in request.files and "image_data" not in request.form:
        return jsonify(error_response("No image provided")[0]), 400

    try:
        if "image" in request.files:
            img_bytes = request.files["image"].read()
        else:
            # base64 data URL from canvas
            data_url = request.form["image_data"]
            header, encoded = data_url.split(",", 1)
            img_bytes = base64.b64decode(encoded)

        input_arr, steps, previews = _process_image_safe(img_bytes)

        if TF_AVAILABLE and _combined_model is not None:
            char, conf, ctype, top5 = _model_predict(input_arr)
        else:
            char, conf, ctype, top5 = _demo_predict(input_arr)

        time_ms = int((time.time() - t0) * 1000)
        _save_record(db, PredictionRecord, char, conf, ctype)

        resp = prediction_response(char, conf, ctype, top5, steps, time_ms)
        resp["previews"] = previews
        resp["demo_mode"] = not (TF_AVAILABLE and _combined_model is not None)
        return jsonify(resp)

    except Exception as exc:
        logger.exception("Predict error")
        return jsonify(error_response(str(exc))[0]), 500


@api_bp.route("/predict/word", methods=["POST"])
def predict_word():
    from app import db, PredictionRecord

    t0 = time.time()

    try:
        if "image" in request.files:
            img_bytes = request.files["image"].read()
        else:
            data_url = request.form.get("image_data", "")
            if not data_url:
                return jsonify(error_response("No image provided")[0]), 400
            _, encoded = data_url.split(",", 1)
            img_bytes = base64.b64decode(encoded)

        img = Image.open(io.BytesIO(img_bytes)).convert("L")
        arr = np.array(img)

        # Segment characters by contour bounding boxes (column projection)
        col_sum = arr.mean(axis=0)
        in_char = False
        segments = []
        start = 0
        for i, v in enumerate(col_sum):
            if v < 240 and not in_char:
                in_char = True
                start = i
            elif v >= 240 and in_char:
                in_char = False
                if i - start > 3:
                    segments.append((start, i))
        if in_char:
            segments.append((start, len(col_sum)))

        if not segments:
            segments = [(0, arr.shape[1])]

        characters = []
        for x1, x2 in segments[:20]:
            crop = img.crop((x1, 0, x2, img.height))
            buf = io.BytesIO()
            crop.save(buf, format="PNG")

            input_arr, steps, _ = _process_image_safe(buf.getvalue())
            if TF_AVAILABLE and _combined_model is not None:
                ch, conf, ctype, top5 = _model_predict(input_arr)
            else:
                ch, conf, ctype, top5 = _demo_predict()

            characters.append({
                "character": ch,
                "confidence": round(conf, 2),
                "type": ctype,
            })
            _save_record(db, PredictionRecord, ch, conf, ctype)

        word = "".join(c["character"] for c in characters)
        time_ms = int((time.time() - t0) * 1000)

        resp = word_response(word, characters, time_ms)
        resp["demo_mode"] = not (TF_AVAILABLE and _combined_model is not None)
        return jsonify(resp)

    except Exception as exc:
        logger.exception("Word predict error")
        return jsonify(error_response(str(exc))[0]), 500


@api_bp.route("/predict/sentence", methods=["POST"])
def predict_sentence():
    from app import db, PredictionRecord

    t0 = time.time()

    try:
        if "image" in request.files:
            img_bytes = request.files["image"].read()
        else:
            data_url = request.form.get("image_data", "")
            if not data_url:
                return jsonify(error_response("No image provided")[0]), 400
            _, encoded = data_url.split(",", 1)
            img_bytes = base64.b64decode(encoded)

        img = Image.open(io.BytesIO(img_bytes)).convert("L")
        arr = np.array(img)

        # Word segmentation via column projection gaps
        col_sum = arr.mean(axis=0)
        in_word = False
        words_segs = []
        w_start = 0
        for i, v in enumerate(col_sum):
            if v < 245 and not in_word:
                in_word = True
                w_start = i
            elif v >= 245 and in_word:
                in_word = False
                if i - w_start > 10:
                    words_segs.append((w_start, i))
        if in_word:
            words_segs.append((w_start, len(col_sum)))

        if not words_segs:
            words_segs = [(0, arr.shape[1])]

        words_out = []
        for wx1, wx2 in words_segs[:10]:
            word_crop = img.crop((wx1, 0, wx2, img.height))
            word_arr = np.array(word_crop)
            col_s = word_arr.mean(axis=0)

            in_char = False
            char_segs = []
            cs = 0
            for i, v in enumerate(col_s):
                if v < 240 and not in_char:
                    in_char = True
                    cs = i
                elif v >= 240 and in_char:
                    in_char = False
                    if i - cs > 2:
                        char_segs.append((wx1 + cs, wx1 + i))
            if in_char:
                char_segs.append((wx1 + cs, wx2))

            if not char_segs:
                char_segs = [(wx1, wx2)]

            chars = []
            for cx1, cx2 in char_segs[:10]:
                crop = img.crop((cx1, 0, cx2, img.height))
                buf = io.BytesIO()
                crop.save(buf, format="PNG")
                input_arr, steps, _ = _process_image_safe(buf.getvalue())
                if TF_AVAILABLE and _combined_model is not None:
                    ch, conf, ctype, top5 = _model_predict(input_arr)
                else:
                    ch, conf, ctype, top5 = _demo_predict()
                chars.append({"character": ch, "confidence": round(conf, 2), "type": ctype})

            words_out.append("".join(c["character"] for c in chars))

        sentence = " ".join(words_out)
        time_ms = int((time.time() - t0) * 1000)

        resp = sentence_response(sentence, words_out, time_ms)
        resp["demo_mode"] = not (TF_AVAILABLE and _combined_model is not None)
        return jsonify(resp)

    except Exception as exc:
        logger.exception("Sentence predict error")
        return jsonify(error_response(str(exc))[0]), 500


@api_bp.route("/history", methods=["GET"])
def get_history():
    from app import db, PredictionRecord
    limit = min(int(request.args.get("limit", 50)), 200)
    records = PredictionRecord.query.order_by(
        PredictionRecord.created_at.desc()
    ).limit(limit).all()
    return jsonify(history_response(records))


@api_bp.route("/history/<int:record_id>", methods=["DELETE"])
def delete_history(record_id):
    from app import db, PredictionRecord
    rec = PredictionRecord.query.get(record_id)
    if not rec:
        return jsonify(error_response("Record not found", 404)[0]), 404
    db.session.delete(rec)
    db.session.commit()
    return jsonify({"success": True, "deleted_id": record_id})


@api_bp.route("/stats", methods=["GET"])
def get_stats():
    from app import db, PredictionRecord
    from sqlalchemy import func

    total = PredictionRecord.query.count()
    avg_conf = db.session.query(func.avg(PredictionRecord.confidence)).scalar() or 0

    by_type_rows = (
        db.session.query(PredictionRecord.char_type, func.count())
        .group_by(PredictionRecord.char_type)
        .all()
    )
    by_type = {row[0]: row[1] for row in by_type_rows}

    most_common_rows = (
        db.session.query(PredictionRecord.character, func.count().label("cnt"))
        .group_by(PredictionRecord.character)
        .order_by(func.count().desc())
        .limit(10)
        .all()
    )
    most_common = [{"character": row[0], "count": row[1]} for row in most_common_rows]

    return jsonify(stats_response(total, float(avg_conf), by_type, most_common))
