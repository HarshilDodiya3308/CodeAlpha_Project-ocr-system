"""JSON serializers for API responses."""

from datetime import datetime


def prediction_response(character, confidence, char_type, top5, processing_steps, time_ms):
    return {
        "success": True,
        "prediction": {
            "character": character,
            "confidence": round(confidence, 2),
            "type": char_type,
            "top5": [
                {"label": item["label"], "probability": round(item["probability"], 2)}
                for item in top5
            ],
        },
        "processing": {
            "time_ms": time_ms,
            "steps_applied": processing_steps,
        },
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }


def word_response(word, characters, time_ms):
    return {
        "success": True,
        "prediction": {
            "word": word,
            "characters": characters,
            "character_count": len(characters),
        },
        "processing": {"time_ms": time_ms},
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }


def sentence_response(sentence, words, time_ms):
    return {
        "success": True,
        "prediction": {
            "sentence": sentence,
            "words": words,
            "word_count": len(words),
        },
        "processing": {"time_ms": time_ms},
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }


def history_response(records):
    return {
        "success": True,
        "history": [
            {
                "id": r.id,
                "character": r.character,
                "confidence": r.confidence,
                "type": r.char_type,
                "timestamp": r.created_at.isoformat() + "Z",
                "image_path": r.image_path,
            }
            for r in records
        ],
        "count": len(records),
    }


def stats_response(total, avg_conf, by_type, most_common):
    return {
        "success": True,
        "stats": {
            "total_predictions": total,
            "average_confidence": round(avg_conf, 2) if avg_conf else 0,
            "by_type": by_type,
            "most_predicted": most_common,
        },
    }


def error_response(message, code=400):
    return {"success": False, "error": message, "code": code}, code
