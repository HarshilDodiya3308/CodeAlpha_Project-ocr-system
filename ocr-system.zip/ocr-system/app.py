"""
Intelligent OCR System — Main Flask Application
"""

import os
import logging
from datetime import datetime

from flask import Flask, render_template, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

from config import Config

# ── App setup ────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.config.from_object(Config)
CORS(app)

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

# ── Database ─────────────────────────────────────────────────────────────────
db = SQLAlchemy(app)


class PredictionRecord(db.Model):
    __tablename__ = "predictions"

    id = db.Column(db.Integer, primary_key=True)
    character = db.Column(db.String(10), nullable=False)
    confidence = db.Column(db.Float, nullable=False)
    char_type = db.Column(db.String(30), nullable=False)
    image_path = db.Column(db.String(255), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Prediction {self.character} ({self.confidence:.1f}%)>"


# ── Ensure folders exist ──────────────────────────────────────────────────────
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(__file__), "database"), exist_ok=True)

with app.app_context():
    db.create_all()
    logger.info("Database tables created / verified")

# ── Register API blueprint ────────────────────────────────────────────────────
from api.routes import api_bp  # noqa: E402

app.register_blueprint(api_bp)

# ── HTML routes ───────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/api-docs")
def api_docs():
    return render_template("api_docs.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = app.config["PORT"]
    debug = app.config["DEBUG"]
    logger.info("Starting OCR System on port %d (debug=%s)", port, debug)
    app.run(host="0.0.0.0", port=port, debug=debug)
